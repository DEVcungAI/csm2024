﻿namespace DuAnPhanMemQuanLyTiemCafe
{
    partial class fEmployees
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fEmployees));
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.giớiThiệuVềChươngTrìnhToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.báoCáoLỗiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tựKhắcPhụcLỗiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.giớiThiệuChứcNăngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trợGiúpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnReturnHome = new System.Windows.Forms.Button();
            this.btnChangEmp = new System.Windows.Forms.Button();
            this.btnAddEmp = new System.Windows.Forms.Button();
            this.txtEmpID = new System.Windows.Forms.TextBox();
            this.lblQPU = new System.Windows.Forms.Label();
            this.lblJntDate = new System.Windows.Forms.Label();
            this.lblEmpAddress = new System.Windows.Forms.Label();
            this.lblEmpName = new System.Windows.Forms.Label();
            this.lblProID = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.thaoTácToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tìmSảnPhẩmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.theoMãToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.theoTênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.theoNgàyCậpNhậtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tùyChọnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xóaSảnPhẩmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sửaThôngTinSảnPhẩmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xóaSảnPhẩmToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.đóngChứcNăngNàyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.txtEmpName = new System.Windows.Forms.TextBox();
            this.txtEmpAddress = new System.Windows.Forms.TextBox();
            this.dtpHiredTime = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtEmpPhone = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Phonenumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Hiredate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Branch = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Department = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Position = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Companyemail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Personalemail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Delete = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Edit = new System.Windows.Forms.DataGridViewButtonColumn();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.btnExptDT = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBox4
            // 
            this.comboBox4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            resources.ApplyResources(this.comboBox4, "comboBox4");
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Name = "comboBox4";
            // 
            // giớiThiệuVềChươngTrìnhToolStripMenuItem
            // 
            resources.ApplyResources(this.giớiThiệuVềChươngTrìnhToolStripMenuItem, "giớiThiệuVềChươngTrìnhToolStripMenuItem");
            this.giớiThiệuVềChươngTrìnhToolStripMenuItem.Name = "giớiThiệuVềChươngTrìnhToolStripMenuItem";
            // 
            // báoCáoLỗiToolStripMenuItem
            // 
            resources.ApplyResources(this.báoCáoLỗiToolStripMenuItem, "báoCáoLỗiToolStripMenuItem");
            this.báoCáoLỗiToolStripMenuItem.Name = "báoCáoLỗiToolStripMenuItem";
            // 
            // tựKhắcPhụcLỗiToolStripMenuItem
            // 
            resources.ApplyResources(this.tựKhắcPhụcLỗiToolStripMenuItem, "tựKhắcPhụcLỗiToolStripMenuItem");
            this.tựKhắcPhụcLỗiToolStripMenuItem.Name = "tựKhắcPhụcLỗiToolStripMenuItem";
            // 
            // giớiThiệuChứcNăngToolStripMenuItem
            // 
            resources.ApplyResources(this.giớiThiệuChứcNăngToolStripMenuItem, "giớiThiệuChứcNăngToolStripMenuItem");
            this.giớiThiệuChứcNăngToolStripMenuItem.Name = "giớiThiệuChứcNăngToolStripMenuItem";
            // 
            // trợGiúpToolStripMenuItem
            // 
            this.trợGiúpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.giớiThiệuChứcNăngToolStripMenuItem,
            this.tựKhắcPhụcLỗiToolStripMenuItem,
            this.báoCáoLỗiToolStripMenuItem,
            this.giớiThiệuVềChươngTrìnhToolStripMenuItem});
            resources.ApplyResources(this.trợGiúpToolStripMenuItem, "trợGiúpToolStripMenuItem");
            this.trợGiúpToolStripMenuItem.Name = "trợGiúpToolStripMenuItem";
            // 
            // btnReturnHome
            // 
            this.btnReturnHome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReturnHome.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.btnReturnHome, "btnReturnHome");
            this.btnReturnHome.Name = "btnReturnHome";
            this.btnReturnHome.UseVisualStyleBackColor = true;
            this.btnReturnHome.Click += new System.EventHandler(this.btnReturnHome_Click);
            // 
            // btnChangEmp
            // 
            this.btnChangEmp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnChangEmp.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.btnChangEmp, "btnChangEmp");
            this.btnChangEmp.Name = "btnChangEmp";
            this.btnChangEmp.UseVisualStyleBackColor = true;
            // 
            // btnAddEmp
            // 
            this.btnAddEmp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddEmp.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.btnAddEmp, "btnAddEmp");
            this.btnAddEmp.Name = "btnAddEmp";
            this.btnAddEmp.UseVisualStyleBackColor = true;
            this.btnAddEmp.Click += new System.EventHandler(this.btnAddEmp_Click);
            // 
            // txtEmpID
            // 
            resources.ApplyResources(this.txtEmpID, "txtEmpID");
            this.txtEmpID.Name = "txtEmpID";
            // 
            // lblQPU
            // 
            resources.ApplyResources(this.lblQPU, "lblQPU");
            this.lblQPU.Name = "lblQPU";
            // 
            // lblJntDate
            // 
            resources.ApplyResources(this.lblJntDate, "lblJntDate");
            this.lblJntDate.Name = "lblJntDate";
            // 
            // lblEmpAddress
            // 
            resources.ApplyResources(this.lblEmpAddress, "lblEmpAddress");
            this.lblEmpAddress.Name = "lblEmpAddress";
            // 
            // lblEmpName
            // 
            resources.ApplyResources(this.lblEmpName, "lblEmpName");
            this.lblEmpName.Name = "lblEmpName";
            // 
            // lblProID
            // 
            resources.ApplyResources(this.lblProID, "lblProID");
            this.lblProID.Name = "lblProID";
            // 
            // menuStrip1
            // 
            resources.ApplyResources(this.menuStrip1, "menuStrip1");
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thaoTácToolStripMenuItem,
            this.trợGiúpToolStripMenuItem});
            this.menuStrip1.Name = "menuStrip1";
            // 
            // thaoTácToolStripMenuItem
            // 
            this.thaoTácToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tìmSảnPhẩmToolStripMenuItem,
            this.xóaSảnPhẩmToolStripMenuItem,
            this.sửaThôngTinSảnPhẩmToolStripMenuItem,
            this.xóaSảnPhẩmToolStripMenuItem1,
            this.đóngChứcNăngNàyToolStripMenuItem});
            resources.ApplyResources(this.thaoTácToolStripMenuItem, "thaoTácToolStripMenuItem");
            this.thaoTácToolStripMenuItem.Name = "thaoTácToolStripMenuItem";
            // 
            // tìmSảnPhẩmToolStripMenuItem
            // 
            this.tìmSảnPhẩmToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.theoMãToolStripMenuItem,
            this.theoTênToolStripMenuItem,
            this.theoNgàyCậpNhậtToolStripMenuItem,
            this.tùyChọnToolStripMenuItem});
            resources.ApplyResources(this.tìmSảnPhẩmToolStripMenuItem, "tìmSảnPhẩmToolStripMenuItem");
            this.tìmSảnPhẩmToolStripMenuItem.Name = "tìmSảnPhẩmToolStripMenuItem";
            // 
            // theoMãToolStripMenuItem
            // 
            resources.ApplyResources(this.theoMãToolStripMenuItem, "theoMãToolStripMenuItem");
            this.theoMãToolStripMenuItem.Name = "theoMãToolStripMenuItem";
            // 
            // theoTênToolStripMenuItem
            // 
            resources.ApplyResources(this.theoTênToolStripMenuItem, "theoTênToolStripMenuItem");
            this.theoTênToolStripMenuItem.Name = "theoTênToolStripMenuItem";
            // 
            // theoNgàyCậpNhậtToolStripMenuItem
            // 
            resources.ApplyResources(this.theoNgàyCậpNhậtToolStripMenuItem, "theoNgàyCậpNhậtToolStripMenuItem");
            this.theoNgàyCậpNhậtToolStripMenuItem.Name = "theoNgàyCậpNhậtToolStripMenuItem";
            // 
            // tùyChọnToolStripMenuItem
            // 
            resources.ApplyResources(this.tùyChọnToolStripMenuItem, "tùyChọnToolStripMenuItem");
            this.tùyChọnToolStripMenuItem.Name = "tùyChọnToolStripMenuItem";
            // 
            // xóaSảnPhẩmToolStripMenuItem
            // 
            resources.ApplyResources(this.xóaSảnPhẩmToolStripMenuItem, "xóaSảnPhẩmToolStripMenuItem");
            this.xóaSảnPhẩmToolStripMenuItem.Name = "xóaSảnPhẩmToolStripMenuItem";
            // 
            // sửaThôngTinSảnPhẩmToolStripMenuItem
            // 
            resources.ApplyResources(this.sửaThôngTinSảnPhẩmToolStripMenuItem, "sửaThôngTinSảnPhẩmToolStripMenuItem");
            this.sửaThôngTinSảnPhẩmToolStripMenuItem.Name = "sửaThôngTinSảnPhẩmToolStripMenuItem";
            // 
            // xóaSảnPhẩmToolStripMenuItem1
            // 
            resources.ApplyResources(this.xóaSảnPhẩmToolStripMenuItem1, "xóaSảnPhẩmToolStripMenuItem1");
            this.xóaSảnPhẩmToolStripMenuItem1.Name = "xóaSảnPhẩmToolStripMenuItem1";
            // 
            // đóngChứcNăngNàyToolStripMenuItem
            // 
            resources.ApplyResources(this.đóngChứcNăngNàyToolStripMenuItem, "đóngChứcNăngNàyToolStripMenuItem");
            this.đóngChứcNăngNàyToolStripMenuItem.Name = "đóngChứcNăngNàyToolStripMenuItem";
            this.đóngChứcNăngNàyToolStripMenuItem.Click += new System.EventHandler(this.đóngChứcNăngNàyToolStripMenuItem_Click);
            // 
            // checkBox1
            // 
            resources.ApplyResources(this.checkBox1, "checkBox1");
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // txtEmpName
            // 
            resources.ApplyResources(this.txtEmpName, "txtEmpName");
            this.txtEmpName.Name = "txtEmpName";
            // 
            // txtEmpAddress
            // 
            resources.ApplyResources(this.txtEmpAddress, "txtEmpAddress");
            this.txtEmpAddress.Name = "txtEmpAddress";
            // 
            // dtpHiredTime
            // 
            resources.ApplyResources(this.dtpHiredTime, "dtpHiredTime");
            this.dtpHiredTime.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dtpHiredTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpHiredTime.Name = "dtpHiredTime";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // comboBox1
            // 
            this.comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            resources.ApplyResources(this.comboBox1, "comboBox1");
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Name = "comboBox1";
            // 
            // textBox4
            // 
            resources.ApplyResources(this.textBox4, "textBox4");
            this.textBox4.Name = "textBox4";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // textBox5
            // 
            resources.ApplyResources(this.textBox5, "textBox5");
            this.textBox5.Name = "textBox5";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // txtEmpPhone
            // 
            resources.ApplyResources(this.txtEmpPhone, "txtEmpPhone");
            this.txtEmpPhone.Name = "txtEmpPhone";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dataGridView1);
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Name = "panel1";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Id,
            this.Name,
            this.Address,
            this.Phonenumber,
            this.Hiredate,
            this.Branch,
            this.Department,
            this.Position,
            this.Companyemail,
            this.Personalemail,
            this.Delete,
            this.Edit});
            resources.ApplyResources(this.dataGridView1, "dataGridView1");
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            // 
            // Id
            // 
            this.Id.DataPropertyName = "id";
            resources.ApplyResources(this.Id, "Id");
            this.Id.Name = "Id";
            // 
            // Name
            // 
            this.Name.DataPropertyName = "name";
            resources.ApplyResources(this.Name, "Name");
            this.Name.Name = "Name";
            // 
            // Address
            // 
            this.Address.DataPropertyName = "address";
            resources.ApplyResources(this.Address, "Address");
            this.Address.Name = "Address";
            // 
            // Phonenumber
            // 
            this.Phonenumber.DataPropertyName = "phonenumber";
            resources.ApplyResources(this.Phonenumber, "Phonenumber");
            this.Phonenumber.Name = "Phonenumber";
            // 
            // Hiredate
            // 
            this.Hiredate.DataPropertyName = "hiredate";
            resources.ApplyResources(this.Hiredate, "Hiredate");
            this.Hiredate.Name = "Hiredate";
            // 
            // Branch
            // 
            this.Branch.DataPropertyName = "branch";
            resources.ApplyResources(this.Branch, "Branch");
            this.Branch.Name = "Branch";
            // 
            // Department
            // 
            this.Department.DataPropertyName = "department";
            resources.ApplyResources(this.Department, "Department");
            this.Department.Name = "Department";
            // 
            // Position
            // 
            this.Position.DataPropertyName = "position";
            resources.ApplyResources(this.Position, "Position");
            this.Position.Name = "Position";
            // 
            // Companyemail
            // 
            this.Companyemail.DataPropertyName = "companyemail";
            resources.ApplyResources(this.Companyemail, "Companyemail");
            this.Companyemail.Name = "Companyemail";
            // 
            // Personalemail
            // 
            this.Personalemail.DataPropertyName = "personalemail";
            resources.ApplyResources(this.Personalemail, "Personalemail");
            this.Personalemail.Name = "Personalemail";
            // 
            // Delete
            // 
            this.Delete.DataPropertyName = "delete";
            resources.ApplyResources(this.Delete, "Delete");
            this.Delete.Name = "Delete";
            // 
            // Edit
            // 
            this.Edit.DataPropertyName = "edit";
            resources.ApplyResources(this.Edit, "Edit");
            this.Edit.Name = "Edit";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // comboBox2
            // 
            this.comboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            resources.ApplyResources(this.comboBox2, "comboBox2");
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Name = "comboBox2";
            // 
            // btnExptDT
            // 
            this.btnExptDT.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExptDT.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.btnExptDT, "btnExptDT");
            this.btnExptDT.Name = "btnExptDT";
            this.btnExptDT.UseVisualStyleBackColor = true;
            // 
            // fEmployees
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dtpHiredTime);
            this.Controls.Add(this.txtEmpAddress);
            this.Controls.Add(this.txtEmpPhone);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.txtEmpName);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.comboBox4);
            this.Controls.Add(this.btnReturnHome);
            this.Controls.Add(this.btnExptDT);
            this.Controls.Add(this.btnChangEmp);
            this.Controls.Add(this.btnAddEmp);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtEmpID);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblQPU);
            this.Controls.Add(this.lblJntDate);
            this.Controls.Add(this.lblEmpAddress);
            this.Controls.Add(this.lblEmpName);
            this.Controls.Add(this.lblProID);
            this.Controls.Add(this.menuStrip1);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ToolStripMenuItem giớiThiệuVềChươngTrìnhToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem báoCáoLỗiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tựKhắcPhụcLỗiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem giớiThiệuChứcNăngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trợGiúpToolStripMenuItem;
        private System.Windows.Forms.Button btnReturnHome;
        private System.Windows.Forms.Button btnChangEmp;
        private System.Windows.Forms.Button btnAddEmp;
        private System.Windows.Forms.TextBox txtEmpID;
        private System.Windows.Forms.Label lblQPU;
        private System.Windows.Forms.Label lblJntDate;
        private System.Windows.Forms.Label lblEmpAddress;
        private System.Windows.Forms.Label lblEmpName;
        private System.Windows.Forms.Label lblProID;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem thaoTácToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tìmSảnPhẩmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem theoMãToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem theoTênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem theoNgàyCậpNhậtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tùyChọnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xóaSảnPhẩmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sửaThôngTinSảnPhẩmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xóaSảnPhẩmToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem đóngChứcNăngNàyToolStripMenuItem;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TextBox txtEmpName;
        private System.Windows.Forms.TextBox txtEmpAddress;
        private System.Windows.Forms.DateTimePicker dtpHiredTime;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtEmpPhone;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Button btnExptDT;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn Address;
        private System.Windows.Forms.DataGridViewTextBoxColumn Phonenumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn Hiredate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Branch;
        private System.Windows.Forms.DataGridViewTextBoxColumn Department;
        private System.Windows.Forms.DataGridViewTextBoxColumn Position;
        private System.Windows.Forms.DataGridViewTextBoxColumn Companyemail;
        private System.Windows.Forms.DataGridViewTextBoxColumn Personalemail;
        private System.Windows.Forms.DataGridViewButtonColumn Delete;
        private System.Windows.Forms.DataGridViewButtonColumn Edit;
    }
}