﻿namespace DuAnPhanMemQuanLyTiemCafe
{
    partial class fLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLogin = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.btnSignup = new System.Windows.Forms.Button();
            this.btnRecInfo = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnRstTxtboxData = new System.Windows.Forms.Button();
            this.tclSignIn = new System.Windows.Forms.TabControl();
            this.tpgSignIn = new System.Windows.Forms.TabPage();
            this.tpgSignUp = new System.Windows.Forms.TabPage();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtSUPhone = new System.Windows.Forms.TextBox();
            this.txtSUCfmPassword = new System.Windows.Forms.TextBox();
            this.txtSUPassword = new System.Windows.Forms.TextBox();
            this.btnSUSignIn = new System.Windows.Forms.Button();
            this.btnSUClear = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnSUExit = new System.Windows.Forms.Button();
            this.txtSUCfmUsername = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtSUUsername = new System.Windows.Forms.TextBox();
            this.btnSURegister = new System.Windows.Forms.Button();
            this.txtSUEmail = new System.Windows.Forms.TextBox();
            this.tpgRecovery = new System.Windows.Forms.TabPage();
            this.label9 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.thaoTácToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thêmNhàCungCấpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chỉnhSửaThôngTinToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xóaNhàCungCấpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đóngCửaSổĐangMởToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.khôiPhụcLạiTrạngTháiBanĐầuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thoátChươngTrìnhToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trợGiúpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.giớiThiệuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.báoCáoLỗiChứcNăngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tclSignIn.SuspendLayout();
            this.tpgSignIn.SuspendLayout();
            this.tpgSignUp.SuspendLayout();
            this.tpgRecovery.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnLogin
            // 
            this.btnLogin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogin.FlatAppearance.BorderSize = 0;
            this.btnLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogin.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.btnLogin.ForeColor = System.Drawing.Color.White;
            this.btnLogin.Location = new System.Drawing.Point(181, 152);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(110, 50);
            this.btnLogin.TabIndex = 3;
            this.btnLogin.Text = "Đăng Nhập";
            this.btnLogin.UseVisualStyleBackColor = false;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(12, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(163, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "Tên Đăng Nhập:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(12, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "Mật Khẩu:";
            // 
            // txtUsername
            // 
            this.txtUsername.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsername.Location = new System.Drawing.Point(236, 39);
            this.txtUsername.MaxLength = 15;
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(200, 27);
            this.txtUsername.TabIndex = 1;
            // 
            // txtPassword
            // 
            this.txtPassword.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassword.Location = new System.Drawing.Point(233, 91);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(200, 27);
            this.txtPassword.TabIndex = 2;
            // 
            // btnSignup
            // 
            this.btnSignup.BackColor = System.Drawing.Color.Silver;
            this.btnSignup.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSignup.FlatAppearance.BorderSize = 0;
            this.btnSignup.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSignup.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.btnSignup.ForeColor = System.Drawing.Color.Black;
            this.btnSignup.Location = new System.Drawing.Point(65, 152);
            this.btnSignup.Name = "btnSignup";
            this.btnSignup.Size = new System.Drawing.Size(110, 50);
            this.btnSignup.TabIndex = 4;
            this.btnSignup.Text = "Đăng Ký";
            this.btnSignup.UseVisualStyleBackColor = false;
            // 
            // btnRecInfo
            // 
            this.btnRecInfo.BackColor = System.Drawing.Color.White;
            this.btnRecInfo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRecInfo.FlatAppearance.BorderSize = 0;
            this.btnRecInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRecInfo.Font = new System.Drawing.Font("Arial", 5.9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.btnRecInfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnRecInfo.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnRecInfo.Location = new System.Drawing.Point(299, 173);
            this.btnRecInfo.Name = "btnRecInfo";
            this.btnRecInfo.Size = new System.Drawing.Size(140, 29);
            this.btnRecInfo.TabIndex = 6;
            this.btnRecInfo.Text = "Quên Mật Khẩu?";
            this.btnRecInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRecInfo.UseVisualStyleBackColor = false;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.OrangeRed;
            this.btnExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExit.FlatAppearance.BorderSize = 0;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.Font = new System.Drawing.Font("Arial", 7.79F, System.Drawing.FontStyle.Bold);
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.Location = new System.Drawing.Point(9, 152);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(50, 50);
            this.btnExit.TabIndex = 8;
            this.btnExit.Text = "X";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnRstTxtboxData
            // 
            this.btnRstTxtboxData.BackColor = System.Drawing.Color.White;
            this.btnRstTxtboxData.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRstTxtboxData.FlatAppearance.BorderSize = 0;
            this.btnRstTxtboxData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRstTxtboxData.Font = new System.Drawing.Font("Arial", 5.9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.btnRstTxtboxData.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnRstTxtboxData.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnRstTxtboxData.Location = new System.Drawing.Point(299, 152);
            this.btnRstTxtboxData.Name = "btnRstTxtboxData";
            this.btnRstTxtboxData.Size = new System.Drawing.Size(140, 29);
            this.btnRstTxtboxData.TabIndex = 7;
            this.btnRstTxtboxData.Text = "Xóa Thông Tin Đăng Nhập";
            this.btnRstTxtboxData.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRstTxtboxData.UseVisualStyleBackColor = false;
            this.btnRstTxtboxData.Click += new System.EventHandler(this.btnResetTextboxData_Click);
            // 
            // tclSignIn
            // 
            this.tclSignIn.Controls.Add(this.tpgSignIn);
            this.tclSignIn.Controls.Add(this.tpgSignUp);
            this.tclSignIn.Controls.Add(this.tpgRecovery);
            this.tclSignIn.Font = new System.Drawing.Font("Arial", 10F);
            this.tclSignIn.Location = new System.Drawing.Point(12, 34);
            this.tclSignIn.Name = "tclSignIn";
            this.tclSignIn.SelectedIndex = 0;
            this.tclSignIn.Size = new System.Drawing.Size(447, 287);
            this.tclSignIn.TabIndex = 9;
            // 
            // tpgSignIn
            // 
            this.tpgSignIn.BackColor = System.Drawing.Color.White;
            this.tpgSignIn.Controls.Add(this.btnLogin);
            this.tpgSignIn.Controls.Add(this.btnRstTxtboxData);
            this.tpgSignIn.Controls.Add(this.label1);
            this.tpgSignIn.Controls.Add(this.btnExit);
            this.tpgSignIn.Controls.Add(this.label2);
            this.tpgSignIn.Controls.Add(this.btnRecInfo);
            this.tpgSignIn.Controls.Add(this.txtUsername);
            this.tpgSignIn.Controls.Add(this.btnSignup);
            this.tpgSignIn.Controls.Add(this.txtPassword);
            this.tpgSignIn.Location = new System.Drawing.Point(4, 28);
            this.tpgSignIn.Name = "tpgSignIn";
            this.tpgSignIn.Padding = new System.Windows.Forms.Padding(3);
            this.tpgSignIn.Size = new System.Drawing.Size(439, 255);
            this.tpgSignIn.TabIndex = 0;
            this.tpgSignIn.Text = "Đăng Nhập";
            this.tpgSignIn.UseVisualStyleBackColor = true;
            // 
            // tpgSignUp
            // 
            this.tpgSignUp.BackColor = System.Drawing.Color.White;
            this.tpgSignUp.Controls.Add(this.label8);
            this.tpgSignUp.Controls.Add(this.label5);
            this.tpgSignUp.Controls.Add(this.label6);
            this.tpgSignUp.Controls.Add(this.txtSUPhone);
            this.tpgSignUp.Controls.Add(this.txtSUCfmPassword);
            this.tpgSignUp.Controls.Add(this.txtSUPassword);
            this.tpgSignUp.Controls.Add(this.btnSUSignIn);
            this.tpgSignUp.Controls.Add(this.btnSUClear);
            this.tpgSignUp.Controls.Add(this.label7);
            this.tpgSignUp.Controls.Add(this.label3);
            this.tpgSignUp.Controls.Add(this.btnSUExit);
            this.tpgSignUp.Controls.Add(this.txtSUCfmUsername);
            this.tpgSignUp.Controls.Add(this.label4);
            this.tpgSignUp.Controls.Add(this.txtSUUsername);
            this.tpgSignUp.Controls.Add(this.btnSURegister);
            this.tpgSignUp.Controls.Add(this.txtSUEmail);
            this.tpgSignUp.Location = new System.Drawing.Point(4, 28);
            this.tpgSignUp.Name = "tpgSignUp";
            this.tpgSignUp.Padding = new System.Windows.Forms.Padding(3);
            this.tpgSignUp.Size = new System.Drawing.Size(439, 255);
            this.tpgSignUp.TabIndex = 1;
            this.tpgSignUp.Text = "Đăng Ký";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(9, 100);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(108, 16);
            this.label8.TabIndex = 18;
            this.label8.Text = "Số Điện Thoại:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(9, 129);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 16);
            this.label5.TabIndex = 18;
            this.label5.Text = "Mật Khẩu:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(9, 158);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(147, 16);
            this.label6.TabIndex = 19;
            this.label6.Text = "Xác Nhận Mật Khẩu:";
            // 
            // txtSUPhone
            // 
            this.txtSUPhone.Font = new System.Drawing.Font("Arial", 8F);
            this.txtSUPhone.Location = new System.Drawing.Point(201, 93);
            this.txtSUPhone.MaxLength = 100;
            this.txtSUPhone.Name = "txtSUPhone";
            this.txtSUPhone.Size = new System.Drawing.Size(215, 23);
            this.txtSUPhone.TabIndex = 20;
            // 
            // txtSUCfmPassword
            // 
            this.txtSUCfmPassword.Font = new System.Drawing.Font("Arial", 8.25F);
            this.txtSUCfmPassword.Location = new System.Drawing.Point(201, 151);
            this.txtSUCfmPassword.Name = "txtSUCfmPassword";
            this.txtSUCfmPassword.PasswordChar = '*';
            this.txtSUCfmPassword.Size = new System.Drawing.Size(215, 23);
            this.txtSUCfmPassword.TabIndex = 21;
            // 
            // txtSUPassword
            // 
            this.txtSUPassword.Font = new System.Drawing.Font("Arial", 8.25F);
            this.txtSUPassword.Location = new System.Drawing.Point(201, 122);
            this.txtSUPassword.Name = "txtSUPassword";
            this.txtSUPassword.PasswordChar = '*';
            this.txtSUPassword.Size = new System.Drawing.Size(215, 23);
            this.txtSUPassword.TabIndex = 21;
            // 
            // btnSUSignIn
            // 
            this.btnSUSignIn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnSUSignIn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSUSignIn.FlatAppearance.BorderSize = 0;
            this.btnSUSignIn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSUSignIn.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.btnSUSignIn.ForeColor = System.Drawing.Color.White;
            this.btnSUSignIn.Location = new System.Drawing.Point(184, 190);
            this.btnSUSignIn.Name = "btnSUSignIn";
            this.btnSUSignIn.Size = new System.Drawing.Size(110, 50);
            this.btnSUSignIn.TabIndex = 9;
            this.btnSUSignIn.Text = "Đăng Nhập";
            this.btnSUSignIn.UseVisualStyleBackColor = false;
            // 
            // btnSUClear
            // 
            this.btnSUClear.BackColor = System.Drawing.Color.White;
            this.btnSUClear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSUClear.FlatAppearance.BorderSize = 0;
            this.btnSUClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSUClear.Font = new System.Drawing.Font("Arial", 5.9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.btnSUClear.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnSUClear.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnSUClear.Location = new System.Drawing.Point(299, 202);
            this.btnSUClear.Name = "btnSUClear";
            this.btnSUClear.Size = new System.Drawing.Size(140, 29);
            this.btnSUClear.TabIndex = 17;
            this.btnSUClear.Text = "Xóa Thông Tin Đăng Nhập";
            this.btnSUClear.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSUClear.UseVisualStyleBackColor = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(9, 42);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(186, 16);
            this.label7.TabIndex = 10;
            this.label7.Text = "Xác Nhận Tên Đăng Nhập:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(9, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(117, 16);
            this.label3.TabIndex = 10;
            this.label3.Text = "Tên Đăng Nhập:";
            // 
            // btnSUExit
            // 
            this.btnSUExit.BackColor = System.Drawing.Color.OrangeRed;
            this.btnSUExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSUExit.FlatAppearance.BorderSize = 0;
            this.btnSUExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSUExit.Font = new System.Drawing.Font("Arial", 7.79F, System.Drawing.FontStyle.Bold);
            this.btnSUExit.ForeColor = System.Drawing.Color.White;
            this.btnSUExit.Location = new System.Drawing.Point(12, 190);
            this.btnSUExit.Name = "btnSUExit";
            this.btnSUExit.Size = new System.Drawing.Size(50, 50);
            this.btnSUExit.TabIndex = 16;
            this.btnSUExit.Text = "X";
            this.btnSUExit.UseVisualStyleBackColor = false;
            // 
            // txtSUCfmUsername
            // 
            this.txtSUCfmUsername.Font = new System.Drawing.Font("Arial", 8F);
            this.txtSUCfmUsername.Location = new System.Drawing.Point(201, 35);
            this.txtSUCfmUsername.MaxLength = 100;
            this.txtSUCfmUsername.Name = "txtSUCfmUsername";
            this.txtSUCfmUsername.Size = new System.Drawing.Size(215, 23);
            this.txtSUCfmUsername.TabIndex = 12;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(9, 71);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 16);
            this.label4.TabIndex = 11;
            this.label4.Text = "E-mail:";
            // 
            // txtSUUsername
            // 
            this.txtSUUsername.Font = new System.Drawing.Font("Arial", 8F);
            this.txtSUUsername.Location = new System.Drawing.Point(201, 6);
            this.txtSUUsername.MaxLength = 15;
            this.txtSUUsername.Name = "txtSUUsername";
            this.txtSUUsername.Size = new System.Drawing.Size(215, 23);
            this.txtSUUsername.TabIndex = 12;
            // 
            // btnSURegister
            // 
            this.btnSURegister.BackColor = System.Drawing.Color.Silver;
            this.btnSURegister.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSURegister.FlatAppearance.BorderSize = 0;
            this.btnSURegister.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSURegister.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.btnSURegister.ForeColor = System.Drawing.Color.Black;
            this.btnSURegister.Location = new System.Drawing.Point(68, 190);
            this.btnSURegister.Name = "btnSURegister";
            this.btnSURegister.Size = new System.Drawing.Size(110, 50);
            this.btnSURegister.TabIndex = 14;
            this.btnSURegister.Text = "Đăng Ký";
            this.btnSURegister.UseVisualStyleBackColor = false;
            // 
            // txtSUEmail
            // 
            this.txtSUEmail.Font = new System.Drawing.Font("Arial", 8.25F);
            this.txtSUEmail.Location = new System.Drawing.Point(201, 64);
            this.txtSUEmail.Name = "txtSUEmail";
            this.txtSUEmail.PasswordChar = '*';
            this.txtSUEmail.Size = new System.Drawing.Size(215, 23);
            this.txtSUEmail.TabIndex = 13;
            // 
            // tpgRecovery
            // 
            this.tpgRecovery.BackColor = System.Drawing.Color.White;
            this.tpgRecovery.Controls.Add(this.label9);
            this.tpgRecovery.Location = new System.Drawing.Point(4, 28);
            this.tpgRecovery.Name = "tpgRecovery";
            this.tpgRecovery.Size = new System.Drawing.Size(439, 255);
            this.tpgRecovery.TabIndex = 2;
            this.tpgRecovery.Text = "Khôi Phục Tài Khoản";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label9.ForeColor = System.Drawing.Color.Tomato;
            this.label9.Location = new System.Drawing.Point(52, 109);
            this.label9.MaximumSize = new System.Drawing.Size(360, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(345, 38);
            this.label9.TabIndex = 0;
            this.label9.Text = "Chức Năng Đang Trong Giai Đoạn Bảo Trì, Vui Lòng Quay Lại Sau (0x15).";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thaoTácToolStripMenuItem,
            this.trợGiúpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(472, 26);
            this.menuStrip1.TabIndex = 10;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // thaoTácToolStripMenuItem
            // 
            this.thaoTácToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thêmNhàCungCấpToolStripMenuItem,
            this.chỉnhSửaThôngTinToolStripMenuItem,
            this.xóaNhàCungCấpToolStripMenuItem,
            this.đóngCửaSổĐangMởToolStripMenuItem,
            this.khôiPhụcLạiTrạngTháiBanĐầuToolStripMenuItem,
            this.thoátChươngTrìnhToolStripMenuItem});
            this.thaoTácToolStripMenuItem.Name = "thaoTácToolStripMenuItem";
            this.thaoTácToolStripMenuItem.Size = new System.Drawing.Size(84, 22);
            this.thaoTácToolStripMenuItem.Text = "Thao Tác";
            // 
            // thêmNhàCungCấpToolStripMenuItem
            // 
            this.thêmNhàCungCấpToolStripMenuItem.Name = "thêmNhàCungCấpToolStripMenuItem";
            this.thêmNhàCungCấpToolStripMenuItem.Size = new System.Drawing.Size(299, 22);
            this.thêmNhàCungCấpToolStripMenuItem.Text = "Thêm Nhà Cung Cấp";
            // 
            // chỉnhSửaThôngTinToolStripMenuItem
            // 
            this.chỉnhSửaThôngTinToolStripMenuItem.Name = "chỉnhSửaThôngTinToolStripMenuItem";
            this.chỉnhSửaThôngTinToolStripMenuItem.Size = new System.Drawing.Size(299, 22);
            this.chỉnhSửaThôngTinToolStripMenuItem.Text = "Chỉnh Sửa Thông Tin";
            // 
            // xóaNhàCungCấpToolStripMenuItem
            // 
            this.xóaNhàCungCấpToolStripMenuItem.Name = "xóaNhàCungCấpToolStripMenuItem";
            this.xóaNhàCungCấpToolStripMenuItem.Size = new System.Drawing.Size(299, 22);
            this.xóaNhàCungCấpToolStripMenuItem.Text = "Xóa Nhà Cung Cấp";
            // 
            // đóngCửaSổĐangMởToolStripMenuItem
            // 
            this.đóngCửaSổĐangMởToolStripMenuItem.Name = "đóngCửaSổĐangMởToolStripMenuItem";
            this.đóngCửaSổĐangMởToolStripMenuItem.Size = new System.Drawing.Size(299, 22);
            this.đóngCửaSổĐangMởToolStripMenuItem.Text = "Đóng Cửa Sổ Đang Chạy";
            // 
            // khôiPhụcLạiTrạngTháiBanĐầuToolStripMenuItem
            // 
            this.khôiPhụcLạiTrạngTháiBanĐầuToolStripMenuItem.Name = "khôiPhụcLạiTrạngTháiBanĐầuToolStripMenuItem";
            this.khôiPhụcLạiTrạngTháiBanĐầuToolStripMenuItem.Size = new System.Drawing.Size(299, 22);
            this.khôiPhụcLạiTrạngTháiBanĐầuToolStripMenuItem.Text = "Khôi Phục Lại Trạng Thái Ban Đầu";
            // 
            // thoátChươngTrìnhToolStripMenuItem
            // 
            this.thoátChươngTrìnhToolStripMenuItem.Name = "thoátChươngTrìnhToolStripMenuItem";
            this.thoátChươngTrìnhToolStripMenuItem.Size = new System.Drawing.Size(299, 22);
            this.thoátChươngTrìnhToolStripMenuItem.Text = "Thoát Chương Trình";
            this.thoátChươngTrìnhToolStripMenuItem.Click += new System.EventHandler(this.thoátChươngTrìnhToolStripMenuItem_Click);
            // 
            // trợGiúpToolStripMenuItem
            // 
            this.trợGiúpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.giớiThiệuToolStripMenuItem,
            this.báoCáoLỗiChứcNăngToolStripMenuItem});
            this.trợGiúpToolStripMenuItem.Name = "trợGiúpToolStripMenuItem";
            this.trợGiúpToolStripMenuItem.Size = new System.Drawing.Size(76, 22);
            this.trợGiúpToolStripMenuItem.Text = "Trợ Giúp";
            // 
            // giớiThiệuToolStripMenuItem
            // 
            this.giớiThiệuToolStripMenuItem.Name = "giớiThiệuToolStripMenuItem";
            this.giớiThiệuToolStripMenuItem.Size = new System.Drawing.Size(230, 22);
            this.giớiThiệuToolStripMenuItem.Text = "Giới Thiệu Chức Năng";
            // 
            // báoCáoLỗiChứcNăngToolStripMenuItem
            // 
            this.báoCáoLỗiChứcNăngToolStripMenuItem.Name = "báoCáoLỗiChứcNăngToolStripMenuItem";
            this.báoCáoLỗiChứcNăngToolStripMenuItem.Size = new System.Drawing.Size(230, 22);
            this.báoCáoLỗiChứcNăngToolStripMenuItem.Text = "Báo Cáo Lỗi Chức Năng";
            // 
            // fLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(472, 328);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.tclSignIn);
            this.Font = new System.Drawing.Font("Arial", 8F);
            this.Name = "fLogin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Truy Cập Hệ Thống";
            this.Load += new System.EventHandler(this.fLogin_Load);
            this.tclSignIn.ResumeLayout(false);
            this.tpgSignIn.ResumeLayout(false);
            this.tpgSignIn.PerformLayout();
            this.tpgSignUp.ResumeLayout(false);
            this.tpgSignUp.PerformLayout();
            this.tpgRecovery.ResumeLayout(false);
            this.tpgRecovery.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Button btnSignup;
        private System.Windows.Forms.Button btnRecInfo;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnRstTxtboxData;
        private System.Windows.Forms.TabControl tclSignIn;
        private System.Windows.Forms.TabPage tpgSignIn;
        private System.Windows.Forms.TabPage tpgSignUp;
        private System.Windows.Forms.TabPage tpgRecovery;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtSUPhone;
        private System.Windows.Forms.TextBox txtSUCfmPassword;
        private System.Windows.Forms.TextBox txtSUPassword;
        private System.Windows.Forms.Button btnSUSignIn;
        private System.Windows.Forms.Button btnSUClear;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnSUExit;
        private System.Windows.Forms.TextBox txtSUCfmUsername;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtSUUsername;
        private System.Windows.Forms.Button btnSURegister;
        private System.Windows.Forms.TextBox txtSUEmail;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem thaoTácToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thêmNhàCungCấpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chỉnhSửaThôngTinToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xóaNhàCungCấpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đóngCửaSổĐangMởToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem khôiPhụcLạiTrạngTháiBanĐầuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thoátChươngTrìnhToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trợGiúpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem giớiThiệuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem báoCáoLỗiChứcNăngToolStripMenuItem;
        private System.Windows.Forms.Label label9;
    }
}