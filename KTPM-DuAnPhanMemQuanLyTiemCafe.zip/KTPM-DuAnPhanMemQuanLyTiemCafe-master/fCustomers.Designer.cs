﻿namespace DuAnPhanMemQuanLyTiemCafe
{
    partial class fCustomers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tùyChọnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sửaThôngTinSảnPhẩmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.xóaSảnPhẩmToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.đóngChứcNăngNàyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.xóaSảnPhẩmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnExptDT = new System.Windows.Forms.Button();
            this.lblCsmAlMail = new System.Windows.Forms.Label();
            this.lblCsmPrMail = new System.Windows.Forms.Label();
            this.lblCsmBrc = new System.Windows.Forms.Label();
            this.lblCsmType = new System.Windows.Forms.Label();
            this.lblCsmPhone = new System.Windows.Forms.Label();
            this.theoNgàyCậpNhậtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.giớiThiệuVềChươngTrìnhToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.báoCáoLỗiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tựKhắcPhụcLỗiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.giớiThiệuChứcNăngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trợGiúpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.btnReturnHome = new System.Windows.Forms.Button();
            this.btnChangCsm = new System.Windows.Forms.Button();
            this.btnAddCtm = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblCsmName = new System.Windows.Forms.Label();
            this.lblCsmID = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.thaoTácToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tìmSảnPhẩmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.theoMãToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.theoTênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lblCsmAdr = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.lblCsmTtl = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tùyChọnToolStripMenuItem
            // 
            this.tùyChọnToolStripMenuItem.Font = new System.Drawing.Font("Arial", 7.8F);
            this.tùyChọnToolStripMenuItem.Name = "tùyChọnToolStripMenuItem";
            this.tùyChọnToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.tùyChọnToolStripMenuItem.Text = "Tùy Chọn";
            // 
            // sửaThôngTinSảnPhẩmToolStripMenuItem
            // 
            this.sửaThôngTinSảnPhẩmToolStripMenuItem.Font = new System.Drawing.Font("Arial", 7.8F);
            this.sửaThôngTinSảnPhẩmToolStripMenuItem.Name = "sửaThôngTinSảnPhẩmToolStripMenuItem";
            this.sửaThôngTinSảnPhẩmToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.sửaThôngTinSảnPhẩmToolStripMenuItem.Text = "Sửa Thông Tin Sản Phẩm";
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(383, 31);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(613, 252);
            this.panel1.TabIndex = 112;
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("Arial", 7.8F);
            this.textBox6.Location = new System.Drawing.Point(176, 261);
            this.textBox6.MaxLength = 20;
            this.textBox6.Multiline = true;
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(200, 22);
            this.textBox6.TabIndex = 110;
            // 
            // xóaSảnPhẩmToolStripMenuItem1
            // 
            this.xóaSảnPhẩmToolStripMenuItem1.Font = new System.Drawing.Font("Arial", 7.8F);
            this.xóaSảnPhẩmToolStripMenuItem1.Name = "xóaSảnPhẩmToolStripMenuItem1";
            this.xóaSảnPhẩmToolStripMenuItem1.Size = new System.Drawing.Size(239, 22);
            this.xóaSảnPhẩmToolStripMenuItem1.Text = "Xóa Sản Phẩm";
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Arial", 7.8F);
            this.textBox5.Location = new System.Drawing.Point(176, 233);
            this.textBox5.MaxLength = 10000;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(200, 22);
            this.textBox5.TabIndex = 109;
            // 
            // đóngChứcNăngNàyToolStripMenuItem
            // 
            this.đóngChứcNăngNàyToolStripMenuItem.Font = new System.Drawing.Font("Arial", 7.8F);
            this.đóngChứcNăngNàyToolStripMenuItem.Name = "đóngChứcNăngNàyToolStripMenuItem";
            this.đóngChứcNăngNàyToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.đóngChứcNăngNàyToolStripMenuItem.Text = "Đóng Chức Năng Này";
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Arial", 7.8F);
            this.textBox4.Location = new System.Drawing.Point(176, 205);
            this.textBox4.MaxLength = 10000;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(200, 22);
            this.textBox4.TabIndex = 107;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox1.Font = new System.Drawing.Font("Arial", 8F);
            this.checkBox1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.checkBox1.Location = new System.Drawing.Point(247, 289);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(129, 20);
            this.checkBox1.TabIndex = 105;
            this.checkBox1.Text = "Ngưng Kết Nối?";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // xóaSảnPhẩmToolStripMenuItem
            // 
            this.xóaSảnPhẩmToolStripMenuItem.Font = new System.Drawing.Font("Arial", 7.8F);
            this.xóaSảnPhẩmToolStripMenuItem.Name = "xóaSảnPhẩmToolStripMenuItem";
            this.xóaSảnPhẩmToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.xóaSảnPhẩmToolStripMenuItem.Text = "Thêm Sản Phẩm";
            // 
            // btnExptDT
            // 
            this.btnExptDT.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExptDT.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnExptDT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExptDT.Font = new System.Drawing.Font("Arial", 7.8F);
            this.btnExptDT.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnExptDT.Location = new System.Drawing.Point(675, 289);
            this.btnExptDT.Name = "btnExptDT";
            this.btnExptDT.Size = new System.Drawing.Size(140, 50);
            this.btnExptDT.TabIndex = 100;
            this.btnExptDT.Text = "Xuất Dữ Liệu";
            this.btnExptDT.UseVisualStyleBackColor = true;
            // 
            // lblCsmAlMail
            // 
            this.lblCsmAlMail.AutoSize = true;
            this.lblCsmAlMail.Font = new System.Drawing.Font("Arial", 7.8F);
            this.lblCsmAlMail.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblCsmAlMail.Location = new System.Drawing.Point(12, 239);
            this.lblCsmAlMail.Name = "lblCsmAlMail";
            this.lblCsmAlMail.Size = new System.Drawing.Size(119, 16);
            this.lblCsmAlMail.TabIndex = 95;
            this.lblCsmAlMail.Text = "E-Mail Dự Phòng:";
            this.lblCsmAlMail.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblCsmPrMail
            // 
            this.lblCsmPrMail.AutoSize = true;
            this.lblCsmPrMail.Font = new System.Drawing.Font("Arial", 7.8F);
            this.lblCsmPrMail.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblCsmPrMail.Location = new System.Drawing.Point(12, 211);
            this.lblCsmPrMail.Name = "lblCsmPrMail";
            this.lblCsmPrMail.Size = new System.Drawing.Size(93, 16);
            this.lblCsmPrMail.TabIndex = 94;
            this.lblCsmPrMail.Text = "E-Mail Chính:";
            this.lblCsmPrMail.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblCsmBrc
            // 
            this.lblCsmBrc.AutoSize = true;
            this.lblCsmBrc.Font = new System.Drawing.Font("Arial", 7.8F);
            this.lblCsmBrc.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblCsmBrc.Location = new System.Drawing.Point(12, 153);
            this.lblCsmBrc.Name = "lblCsmBrc";
            this.lblCsmBrc.Size = new System.Drawing.Size(78, 16);
            this.lblCsmBrc.TabIndex = 93;
            this.lblCsmBrc.Text = "Chi Nhánh:";
            this.lblCsmBrc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblCsmType
            // 
            this.lblCsmType.AutoSize = true;
            this.lblCsmType.Font = new System.Drawing.Font("Arial", 7.8F);
            this.lblCsmType.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblCsmType.Location = new System.Drawing.Point(12, 123);
            this.lblCsmType.Name = "lblCsmType";
            this.lblCsmType.Size = new System.Drawing.Size(121, 16);
            this.lblCsmType.TabIndex = 91;
            this.lblCsmType.Text = "Kiểu Khách Hàng:";
            this.lblCsmType.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblCsmPhone
            // 
            this.lblCsmPhone.AutoSize = true;
            this.lblCsmPhone.Font = new System.Drawing.Font("Arial", 7.8F);
            this.lblCsmPhone.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblCsmPhone.Location = new System.Drawing.Point(12, 267);
            this.lblCsmPhone.Name = "lblCsmPhone";
            this.lblCsmPhone.Size = new System.Drawing.Size(102, 16);
            this.lblCsmPhone.TabIndex = 92;
            this.lblCsmPhone.Text = "Số Điện Thoại:";
            this.lblCsmPhone.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // theoNgàyCậpNhậtToolStripMenuItem
            // 
            this.theoNgàyCậpNhậtToolStripMenuItem.Font = new System.Drawing.Font("Arial", 7.8F);
            this.theoNgàyCậpNhậtToolStripMenuItem.Name = "theoNgàyCậpNhậtToolStripMenuItem";
            this.theoNgàyCậpNhậtToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.theoNgàyCậpNhậtToolStripMenuItem.Text = "Theo Ngày Cập Nhật";
            // 
            // comboBox4
            // 
            this.comboBox4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox4.Font = new System.Drawing.Font("Arial", 7.8F);
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(176, 145);
            this.comboBox4.MaxLength = 100000;
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(200, 24);
            this.comboBox4.TabIndex = 103;
            // 
            // giớiThiệuVềChươngTrìnhToolStripMenuItem
            // 
            this.giớiThiệuVềChươngTrìnhToolStripMenuItem.Font = new System.Drawing.Font("Arial", 7.8F);
            this.giớiThiệuVềChươngTrìnhToolStripMenuItem.Name = "giớiThiệuVềChươngTrìnhToolStripMenuItem";
            this.giớiThiệuVềChươngTrìnhToolStripMenuItem.Size = new System.Drawing.Size(256, 22);
            this.giớiThiệuVềChươngTrìnhToolStripMenuItem.Text = "Giới Thiệu Về Chương Trình";
            // 
            // báoCáoLỗiToolStripMenuItem
            // 
            this.báoCáoLỗiToolStripMenuItem.Font = new System.Drawing.Font("Arial", 7.8F);
            this.báoCáoLỗiToolStripMenuItem.Name = "báoCáoLỗiToolStripMenuItem";
            this.báoCáoLỗiToolStripMenuItem.Size = new System.Drawing.Size(256, 22);
            this.báoCáoLỗiToolStripMenuItem.Text = "Báo Cáo Lỗi";
            // 
            // tựKhắcPhụcLỗiToolStripMenuItem
            // 
            this.tựKhắcPhụcLỗiToolStripMenuItem.Font = new System.Drawing.Font("Arial", 7.8F);
            this.tựKhắcPhụcLỗiToolStripMenuItem.Name = "tựKhắcPhụcLỗiToolStripMenuItem";
            this.tựKhắcPhụcLỗiToolStripMenuItem.Size = new System.Drawing.Size(256, 22);
            this.tựKhắcPhụcLỗiToolStripMenuItem.Text = "Tự Khắc Phục Lỗi";
            // 
            // giớiThiệuChứcNăngToolStripMenuItem
            // 
            this.giớiThiệuChứcNăngToolStripMenuItem.Font = new System.Drawing.Font("Arial", 7.8F);
            this.giớiThiệuChứcNăngToolStripMenuItem.Name = "giớiThiệuChứcNăngToolStripMenuItem";
            this.giớiThiệuChứcNăngToolStripMenuItem.Size = new System.Drawing.Size(256, 22);
            this.giớiThiệuChứcNăngToolStripMenuItem.Text = "Giới Thiệu Chức Năng";
            // 
            // trợGiúpToolStripMenuItem
            // 
            this.trợGiúpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.giớiThiệuChứcNăngToolStripMenuItem,
            this.tựKhắcPhụcLỗiToolStripMenuItem,
            this.báoCáoLỗiToolStripMenuItem,
            this.giớiThiệuVềChươngTrìnhToolStripMenuItem});
            this.trợGiúpToolStripMenuItem.Font = new System.Drawing.Font("Arial", 7.8F);
            this.trợGiúpToolStripMenuItem.Name = "trợGiúpToolStripMenuItem";
            this.trợGiúpToolStripMenuItem.Size = new System.Drawing.Size(76, 20);
            this.trợGiúpToolStripMenuItem.Text = "Trợ Giúp";
            // 
            // comboBox2
            // 
            this.comboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox2.Font = new System.Drawing.Font("Arial", 7.8F);
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(176, 175);
            this.comboBox2.MaxLength = 500;
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(200, 24);
            this.comboBox2.TabIndex = 104;
            // 
            // btnReturnHome
            // 
            this.btnReturnHome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReturnHome.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnReturnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReturnHome.Font = new System.Drawing.Font("Arial", 7.8F);
            this.btnReturnHome.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnReturnHome.Location = new System.Drawing.Point(821, 289);
            this.btnReturnHome.Name = "btnReturnHome";
            this.btnReturnHome.Size = new System.Drawing.Size(175, 50);
            this.btnReturnHome.TabIndex = 101;
            this.btnReturnHome.Text = "Trở Về Màn Hình Chính";
            this.btnReturnHome.UseVisualStyleBackColor = true;
            this.btnReturnHome.Click += new System.EventHandler(this.btnReturnHome_Click);
            // 
            // btnChangCsm
            // 
            this.btnChangCsm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnChangCsm.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnChangCsm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChangCsm.Font = new System.Drawing.Font("Arial", 7.8F);
            this.btnChangCsm.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnChangCsm.Location = new System.Drawing.Point(529, 289);
            this.btnChangCsm.Name = "btnChangCsm";
            this.btnChangCsm.Size = new System.Drawing.Size(140, 50);
            this.btnChangCsm.TabIndex = 99;
            this.btnChangCsm.Text = "Sửa Thông Tin";
            this.btnChangCsm.UseVisualStyleBackColor = true;
            // 
            // btnAddCtm
            // 
            this.btnAddCtm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddCtm.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnAddCtm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddCtm.Font = new System.Drawing.Font("Arial", 7.8F);
            this.btnAddCtm.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnAddCtm.Location = new System.Drawing.Point(383, 289);
            this.btnAddCtm.Name = "btnAddCtm";
            this.btnAddCtm.Size = new System.Drawing.Size(140, 50);
            this.btnAddCtm.TabIndex = 98;
            this.btnAddCtm.Text = "Thêm Khách Hàng";
            this.btnAddCtm.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Arial", 7.8F);
            this.textBox1.Location = new System.Drawing.Point(176, 31);
            this.textBox1.MaxLength = 50;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(200, 22);
            this.textBox1.TabIndex = 97;
            // 
            // lblCsmName
            // 
            this.lblCsmName.AutoSize = true;
            this.lblCsmName.Font = new System.Drawing.Font("Arial", 7.8F);
            this.lblCsmName.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblCsmName.Location = new System.Drawing.Point(12, 95);
            this.lblCsmName.Name = "lblCsmName";
            this.lblCsmName.Size = new System.Drawing.Size(118, 16);
            this.lblCsmName.TabIndex = 89;
            this.lblCsmName.Text = "Tên Khách Hàng:";
            this.lblCsmName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblCsmID
            // 
            this.lblCsmID.AutoSize = true;
            this.lblCsmID.Font = new System.Drawing.Font("Arial", 7.8F);
            this.lblCsmID.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblCsmID.Location = new System.Drawing.Point(12, 37);
            this.lblCsmID.Name = "lblCsmID";
            this.lblCsmID.Size = new System.Drawing.Size(112, 16);
            this.lblCsmID.TabIndex = 87;
            this.lblCsmID.Text = "Mã Khách Hàng:";
            this.lblCsmID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Arial", 7.8F);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thaoTácToolStripMenuItem,
            this.trợGiúpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1002, 24);
            this.menuStrip1.TabIndex = 86;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // thaoTácToolStripMenuItem
            // 
            this.thaoTácToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tìmSảnPhẩmToolStripMenuItem,
            this.xóaSảnPhẩmToolStripMenuItem,
            this.sửaThôngTinSảnPhẩmToolStripMenuItem,
            this.xóaSảnPhẩmToolStripMenuItem1,
            this.đóngChứcNăngNàyToolStripMenuItem});
            this.thaoTácToolStripMenuItem.Font = new System.Drawing.Font("Arial", 7.8F);
            this.thaoTácToolStripMenuItem.Name = "thaoTácToolStripMenuItem";
            this.thaoTácToolStripMenuItem.Size = new System.Drawing.Size(81, 20);
            this.thaoTácToolStripMenuItem.Text = "Thao Tác";
            // 
            // tìmSảnPhẩmToolStripMenuItem
            // 
            this.tìmSảnPhẩmToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.theoMãToolStripMenuItem,
            this.theoTênToolStripMenuItem,
            this.theoNgàyCậpNhậtToolStripMenuItem,
            this.tùyChọnToolStripMenuItem});
            this.tìmSảnPhẩmToolStripMenuItem.Font = new System.Drawing.Font("Arial", 7.8F);
            this.tìmSảnPhẩmToolStripMenuItem.Name = "tìmSảnPhẩmToolStripMenuItem";
            this.tìmSảnPhẩmToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.tìmSảnPhẩmToolStripMenuItem.Text = "Tìm Sản Phẩm";
            // 
            // theoMãToolStripMenuItem
            // 
            this.theoMãToolStripMenuItem.Font = new System.Drawing.Font("Arial", 7.8F);
            this.theoMãToolStripMenuItem.Name = "theoMãToolStripMenuItem";
            this.theoMãToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.theoMãToolStripMenuItem.Text = "Theo Mã";
            // 
            // theoTênToolStripMenuItem
            // 
            this.theoTênToolStripMenuItem.Font = new System.Drawing.Font("Arial", 7.8F);
            this.theoTênToolStripMenuItem.Name = "theoTênToolStripMenuItem";
            this.theoTênToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.theoTênToolStripMenuItem.Text = "Theo Tên";
            // 
            // lblCsmAdr
            // 
            this.lblCsmAdr.AutoSize = true;
            this.lblCsmAdr.Font = new System.Drawing.Font("Arial", 7.8F);
            this.lblCsmAdr.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblCsmAdr.Location = new System.Drawing.Point(12, 183);
            this.lblCsmAdr.Name = "lblCsmAdr";
            this.lblCsmAdr.Size = new System.Drawing.Size(58, 16);
            this.lblCsmAdr.TabIndex = 89;
            this.lblCsmAdr.Text = "Địa Chỉ:";
            this.lblCsmAdr.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Arial", 7.8F);
            this.textBox2.Location = new System.Drawing.Point(176, 89);
            this.textBox2.MaxLength = 250;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(200, 22);
            this.textBox2.TabIndex = 108;
            // 
            // lblCsmTtl
            // 
            this.lblCsmTtl.AutoSize = true;
            this.lblCsmTtl.Font = new System.Drawing.Font("Arial", 7.8F);
            this.lblCsmTtl.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblCsmTtl.Location = new System.Drawing.Point(12, 67);
            this.lblCsmTtl.Name = "lblCsmTtl";
            this.lblCsmTtl.Size = new System.Drawing.Size(83, 16);
            this.lblCsmTtl.TabIndex = 89;
            this.lblCsmTtl.Text = "Danh Xưng:";
            this.lblCsmTtl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // comboBox1
            // 
            this.comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox1.Font = new System.Drawing.Font("Arial", 7.8F);
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(176, 59);
            this.comboBox1.MaxLength = 100000;
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(200, 24);
            this.comboBox1.TabIndex = 103;
            // 
            // comboBox3
            // 
            this.comboBox3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox3.Font = new System.Drawing.Font("Arial", 7.8F);
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(176, 115);
            this.comboBox3.MaxLength = 100000;
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(200, 24);
            this.comboBox3.TabIndex = 103;
            // 
            // fCustomers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1002, 346);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.btnExptDT);
            this.Controls.Add(this.lblCsmAlMail);
            this.Controls.Add(this.lblCsmPrMail);
            this.Controls.Add(this.lblCsmBrc);
            this.Controls.Add(this.lblCsmType);
            this.Controls.Add(this.lblCsmPhone);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.comboBox4);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.btnReturnHome);
            this.Controls.Add(this.btnChangCsm);
            this.Controls.Add(this.btnAddCtm);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblCsmTtl);
            this.Controls.Add(this.lblCsmAdr);
            this.Controls.Add(this.lblCsmName);
            this.Controls.Add(this.lblCsmID);
            this.Controls.Add(this.menuStrip1);
            this.Name = "fCustomers";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Khách Hàng - Chương Trình Quản Lý Tiệm Cafe";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem tùyChọnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sửaThôngTinSảnPhẩmToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.ToolStripMenuItem xóaSảnPhẩmToolStripMenuItem1;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.ToolStripMenuItem đóngChứcNăngNàyToolStripMenuItem;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.ToolStripMenuItem xóaSảnPhẩmToolStripMenuItem;
        private System.Windows.Forms.Button btnExptDT;
        private System.Windows.Forms.Label lblCsmAlMail;
        private System.Windows.Forms.Label lblCsmPrMail;
        private System.Windows.Forms.Label lblCsmBrc;
        private System.Windows.Forms.Label lblCsmType;
        private System.Windows.Forms.Label lblCsmPhone;
        private System.Windows.Forms.ToolStripMenuItem theoNgàyCậpNhậtToolStripMenuItem;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ToolStripMenuItem giớiThiệuVềChươngTrìnhToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem báoCáoLỗiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tựKhắcPhụcLỗiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem giớiThiệuChứcNăngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trợGiúpToolStripMenuItem;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Button btnReturnHome;
        private System.Windows.Forms.Button btnChangCsm;
        private System.Windows.Forms.Button btnAddCtm;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblCsmName;
        private System.Windows.Forms.Label lblCsmID;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem thaoTácToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tìmSảnPhẩmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem theoMãToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem theoTênToolStripMenuItem;
        private System.Windows.Forms.Label lblCsmAdr;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label lblCsmTtl;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox3;

    }
}