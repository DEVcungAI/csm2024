﻿namespace DuAnPhanMemQuanLyTiemCafe
{
    partial class fCheckout
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.thaoTácToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lưuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xuấtHóaĐơnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pDFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.excelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xLSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xLSXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dOCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dOCXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jPGToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pNGToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gIFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đóngCửaSổHiệnHànhToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chuyểnSangChứcNăngKhácToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trợGiúpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.giớiThiệuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chứcNăngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chươngTrìnhToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.báoCáoLỗiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thaoTácToolStripMenuItem,
            this.trợGiúpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1008, 26);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // thaoTácToolStripMenuItem
            // 
            this.thaoTácToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lưuToolStripMenuItem,
            this.xuấtHóaĐơnToolStripMenuItem,
            this.đóngCửaSổHiệnHànhToolStripMenuItem,
            this.chuyểnSangChứcNăngKhácToolStripMenuItem});
            this.thaoTácToolStripMenuItem.Name = "thaoTácToolStripMenuItem";
            this.thaoTácToolStripMenuItem.Size = new System.Drawing.Size(84, 22);
            this.thaoTácToolStripMenuItem.Text = "Thao Tác";
            // 
            // lưuToolStripMenuItem
            // 
            this.lưuToolStripMenuItem.Name = "lưuToolStripMenuItem";
            this.lưuToolStripMenuItem.Size = new System.Drawing.Size(276, 22);
            this.lưuToolStripMenuItem.Text = "Lưu Hóa Đơn";
            // 
            // xuấtHóaĐơnToolStripMenuItem
            // 
            this.xuấtHóaĐơnToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pDFToolStripMenuItem,
            this.excelToolStripMenuItem,
            this.wordToolStripMenuItem,
            this.jPGToolStripMenuItem,
            this.pNGToolStripMenuItem,
            this.gIFToolStripMenuItem});
            this.xuấtHóaĐơnToolStripMenuItem.Name = "xuấtHóaĐơnToolStripMenuItem";
            this.xuấtHóaĐơnToolStripMenuItem.Size = new System.Drawing.Size(276, 22);
            this.xuấtHóaĐơnToolStripMenuItem.Text = "Xuất Hóa Đơn";
            // 
            // pDFToolStripMenuItem
            // 
            this.pDFToolStripMenuItem.Name = "pDFToolStripMenuItem";
            this.pDFToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.pDFToolStripMenuItem.Text = "PDF";
            // 
            // excelToolStripMenuItem
            // 
            this.excelToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.xLSToolStripMenuItem,
            this.xLSXToolStripMenuItem});
            this.excelToolStripMenuItem.Name = "excelToolStripMenuItem";
            this.excelToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.excelToolStripMenuItem.Text = "Excel";
            // 
            // xLSToolStripMenuItem
            // 
            this.xLSToolStripMenuItem.Name = "xLSToolStripMenuItem";
            this.xLSToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.xLSToolStripMenuItem.Text = "XLS";
            // 
            // xLSXToolStripMenuItem
            // 
            this.xLSXToolStripMenuItem.Name = "xLSXToolStripMenuItem";
            this.xLSXToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.xLSXToolStripMenuItem.Text = "XLSX";
            // 
            // wordToolStripMenuItem
            // 
            this.wordToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dOCToolStripMenuItem,
            this.dOCXToolStripMenuItem});
            this.wordToolStripMenuItem.Name = "wordToolStripMenuItem";
            this.wordToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.wordToolStripMenuItem.Text = "Word";
            // 
            // dOCToolStripMenuItem
            // 
            this.dOCToolStripMenuItem.Name = "dOCToolStripMenuItem";
            this.dOCToolStripMenuItem.Size = new System.Drawing.Size(115, 22);
            this.dOCToolStripMenuItem.Text = "DOC";
            // 
            // dOCXToolStripMenuItem
            // 
            this.dOCXToolStripMenuItem.Name = "dOCXToolStripMenuItem";
            this.dOCXToolStripMenuItem.Size = new System.Drawing.Size(115, 22);
            this.dOCXToolStripMenuItem.Text = "DOCX";
            // 
            // jPGToolStripMenuItem
            // 
            this.jPGToolStripMenuItem.Name = "jPGToolStripMenuItem";
            this.jPGToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.jPGToolStripMenuItem.Text = "JPG";
            // 
            // pNGToolStripMenuItem
            // 
            this.pNGToolStripMenuItem.Name = "pNGToolStripMenuItem";
            this.pNGToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.pNGToolStripMenuItem.Text = "PNG";
            // 
            // gIFToolStripMenuItem
            // 
            this.gIFToolStripMenuItem.Name = "gIFToolStripMenuItem";
            this.gIFToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.gIFToolStripMenuItem.Text = "GIF";
            // 
            // đóngCửaSổHiệnHànhToolStripMenuItem
            // 
            this.đóngCửaSổHiệnHànhToolStripMenuItem.Name = "đóngCửaSổHiệnHànhToolStripMenuItem";
            this.đóngCửaSổHiệnHànhToolStripMenuItem.Size = new System.Drawing.Size(276, 22);
            this.đóngCửaSổHiệnHànhToolStripMenuItem.Text = "Đóng Cửa Sổ Hiện Hành";
            // 
            // chuyểnSangChứcNăngKhácToolStripMenuItem
            // 
            this.chuyểnSangChứcNăngKhácToolStripMenuItem.Name = "chuyểnSangChứcNăngKhácToolStripMenuItem";
            this.chuyểnSangChứcNăngKhácToolStripMenuItem.Size = new System.Drawing.Size(276, 22);
            this.chuyểnSangChứcNăngKhácToolStripMenuItem.Text = "Chuyển Sang Chức Năng Khác";
            // 
            // trợGiúpToolStripMenuItem
            // 
            this.trợGiúpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.giớiThiệuToolStripMenuItem,
            this.báoCáoLỗiToolStripMenuItem});
            this.trợGiúpToolStripMenuItem.Name = "trợGiúpToolStripMenuItem";
            this.trợGiúpToolStripMenuItem.Size = new System.Drawing.Size(76, 22);
            this.trợGiúpToolStripMenuItem.Text = "Trợ Giúp";
            // 
            // giớiThiệuToolStripMenuItem
            // 
            this.giớiThiệuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.chứcNăngToolStripMenuItem,
            this.chươngTrìnhToolStripMenuItem});
            this.giớiThiệuToolStripMenuItem.Name = "giớiThiệuToolStripMenuItem";
            this.giớiThiệuToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.giớiThiệuToolStripMenuItem.Text = "Giới Thiệu";
            // 
            // chứcNăngToolStripMenuItem
            // 
            this.chứcNăngToolStripMenuItem.Name = "chứcNăngToolStripMenuItem";
            this.chứcNăngToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.chứcNăngToolStripMenuItem.Text = "Chức Năng";
            // 
            // chươngTrìnhToolStripMenuItem
            // 
            this.chươngTrìnhToolStripMenuItem.Name = "chươngTrìnhToolStripMenuItem";
            this.chươngTrìnhToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.chươngTrìnhToolStripMenuItem.Text = "Chương Trình";
            // 
            // báoCáoLỗiToolStripMenuItem
            // 
            this.báoCáoLỗiToolStripMenuItem.Name = "báoCáoLỗiToolStripMenuItem";
            this.báoCáoLỗiToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.báoCáoLỗiToolStripMenuItem.Text = "Báo Cáo Lỗi";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 30F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(107, 148);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(792, 34);
            this.label1.TabIndex = 1;
            this.label1.Text = "Xin Lỗi, Chức Năng Này Đang Trong Giai Đoạn Bảo Trì.";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Bisque;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Arial", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Pixel);
            this.button1.ForeColor = System.Drawing.Color.Blue;
            this.button1.Location = new System.Drawing.Point(762, 239);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(234, 100);
            this.button1.TabIndex = 2;
            this.button1.Text = "Thoát Chương Trình";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // fCheckout
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1008, 351);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "fCheckout";
            this.Text = "Thanh Toán - Chương Trình Quản Lý Tiệm Cafe";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem thaoTácToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lưuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xuấtHóaĐơnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pDFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem excelToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xLSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xLSXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dOCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dOCXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jPGToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pNGToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gIFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đóngCửaSổHiệnHànhToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chuyểnSangChứcNăngKhácToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trợGiúpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem giớiThiệuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chứcNăngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chươngTrìnhToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem báoCáoLỗiToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
    }
}