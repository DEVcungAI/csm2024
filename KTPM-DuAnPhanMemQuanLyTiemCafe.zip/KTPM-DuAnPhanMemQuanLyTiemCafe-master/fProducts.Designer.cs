﻿namespace DuAnPhanMemQuanLyTiemCafe
{
    partial class fProducts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.thaoTácToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tìmSảnPhẩmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.theoMãToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.theoTênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.theoNgàyCậpNhậtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tùyChọnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xóaSảnPhẩmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sửaThôngTinSảnPhẩmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xóaSảnPhẩmToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.đóngChứcNăngNàyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trợGiúpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.giớiThiệuChứcNăngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tựKhắcPhụcLỗiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.báoCáoLỗiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.giớiThiệuVềChươngTrìnhToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.btnReturnHome = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnRemPro = new System.Windows.Forms.Button();
            this.btnEdiPro = new System.Windows.Forms.Button();
            this.btnAddPro = new System.Windows.Forms.Button();
            this.btnViewPro = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.lblUOO = new System.Windows.Forms.Label();
            this.lblUIS = new System.Windows.Forms.Label();
            this.lblUniPri = new System.Windows.Forms.Label();
            this.lblQPU = new System.Windows.Forms.Label();
            this.lblProCat = new System.Windows.Forms.Label();
            this.lblSuppliers = new System.Windows.Forms.Label();
            this.lblProName = new System.Windows.Forms.Label();
            this.lblProID = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thaoTácToolStripMenuItem,
            this.trợGiúpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(538, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // thaoTácToolStripMenuItem
            // 
            this.thaoTácToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tìmSảnPhẩmToolStripMenuItem,
            this.xóaSảnPhẩmToolStripMenuItem,
            this.sửaThôngTinSảnPhẩmToolStripMenuItem,
            this.xóaSảnPhẩmToolStripMenuItem1,
            this.đóngChứcNăngNàyToolStripMenuItem});
            this.thaoTácToolStripMenuItem.Font = new System.Drawing.Font("Arial", 8F);
            this.thaoTácToolStripMenuItem.Name = "thaoTácToolStripMenuItem";
            this.thaoTácToolStripMenuItem.Size = new System.Drawing.Size(81, 20);
            this.thaoTácToolStripMenuItem.Text = "Thao Tác";
            // 
            // tìmSảnPhẩmToolStripMenuItem
            // 
            this.tìmSảnPhẩmToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.theoMãToolStripMenuItem,
            this.theoTênToolStripMenuItem,
            this.theoNgàyCậpNhậtToolStripMenuItem,
            this.tùyChọnToolStripMenuItem});
            this.tìmSảnPhẩmToolStripMenuItem.Name = "tìmSảnPhẩmToolStripMenuItem";
            this.tìmSảnPhẩmToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.tìmSảnPhẩmToolStripMenuItem.Text = "Tìm Sản Phẩm";
            // 
            // theoMãToolStripMenuItem
            // 
            this.theoMãToolStripMenuItem.Name = "theoMãToolStripMenuItem";
            this.theoMãToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.theoMãToolStripMenuItem.Text = "Theo Mã";
            // 
            // theoTênToolStripMenuItem
            // 
            this.theoTênToolStripMenuItem.Name = "theoTênToolStripMenuItem";
            this.theoTênToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.theoTênToolStripMenuItem.Text = "Theo Tên";
            // 
            // theoNgàyCậpNhậtToolStripMenuItem
            // 
            this.theoNgàyCậpNhậtToolStripMenuItem.Name = "theoNgàyCậpNhậtToolStripMenuItem";
            this.theoNgàyCậpNhậtToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.theoNgàyCậpNhậtToolStripMenuItem.Text = "Theo Ngày Cập Nhật";
            // 
            // tùyChọnToolStripMenuItem
            // 
            this.tùyChọnToolStripMenuItem.Name = "tùyChọnToolStripMenuItem";
            this.tùyChọnToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.tùyChọnToolStripMenuItem.Text = "Tùy Chọn";
            // 
            // xóaSảnPhẩmToolStripMenuItem
            // 
            this.xóaSảnPhẩmToolStripMenuItem.Name = "xóaSảnPhẩmToolStripMenuItem";
            this.xóaSảnPhẩmToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.xóaSảnPhẩmToolStripMenuItem.Text = "Thêm Sản Phẩm";
            // 
            // sửaThôngTinSảnPhẩmToolStripMenuItem
            // 
            this.sửaThôngTinSảnPhẩmToolStripMenuItem.Name = "sửaThôngTinSảnPhẩmToolStripMenuItem";
            this.sửaThôngTinSảnPhẩmToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.sửaThôngTinSảnPhẩmToolStripMenuItem.Text = "Sửa Thông Tin Sản Phẩm";
            // 
            // xóaSảnPhẩmToolStripMenuItem1
            // 
            this.xóaSảnPhẩmToolStripMenuItem1.Name = "xóaSảnPhẩmToolStripMenuItem1";
            this.xóaSảnPhẩmToolStripMenuItem1.Size = new System.Drawing.Size(239, 22);
            this.xóaSảnPhẩmToolStripMenuItem1.Text = "Xóa Sản Phẩm";
            // 
            // đóngChứcNăngNàyToolStripMenuItem
            // 
            this.đóngChứcNăngNàyToolStripMenuItem.Name = "đóngChứcNăngNàyToolStripMenuItem";
            this.đóngChứcNăngNàyToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.đóngChứcNăngNàyToolStripMenuItem.Text = "Đóng Chức Năng Này";
            this.đóngChứcNăngNàyToolStripMenuItem.Click += new System.EventHandler(this.đóngChứcNăngNàyToolStripMenuItem_Click);
            // 
            // trợGiúpToolStripMenuItem
            // 
            this.trợGiúpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.giớiThiệuChứcNăngToolStripMenuItem,
            this.tựKhắcPhụcLỗiToolStripMenuItem,
            this.báoCáoLỗiToolStripMenuItem,
            this.giớiThiệuVềChươngTrìnhToolStripMenuItem});
            this.trợGiúpToolStripMenuItem.Font = new System.Drawing.Font("Arial", 8F);
            this.trợGiúpToolStripMenuItem.Name = "trợGiúpToolStripMenuItem";
            this.trợGiúpToolStripMenuItem.Size = new System.Drawing.Size(76, 20);
            this.trợGiúpToolStripMenuItem.Text = "Trợ Giúp";
            // 
            // giớiThiệuChứcNăngToolStripMenuItem
            // 
            this.giớiThiệuChứcNăngToolStripMenuItem.Name = "giớiThiệuChứcNăngToolStripMenuItem";
            this.giớiThiệuChứcNăngToolStripMenuItem.Size = new System.Drawing.Size(256, 22);
            this.giớiThiệuChứcNăngToolStripMenuItem.Text = "Giới Thiệu Chức Năng";
            // 
            // tựKhắcPhụcLỗiToolStripMenuItem
            // 
            this.tựKhắcPhụcLỗiToolStripMenuItem.Name = "tựKhắcPhụcLỗiToolStripMenuItem";
            this.tựKhắcPhụcLỗiToolStripMenuItem.Size = new System.Drawing.Size(256, 22);
            this.tựKhắcPhụcLỗiToolStripMenuItem.Text = "Tự Khắc Phục Lỗi";
            // 
            // báoCáoLỗiToolStripMenuItem
            // 
            this.báoCáoLỗiToolStripMenuItem.Name = "báoCáoLỗiToolStripMenuItem";
            this.báoCáoLỗiToolStripMenuItem.Size = new System.Drawing.Size(256, 22);
            this.báoCáoLỗiToolStripMenuItem.Text = "Báo Cáo Lỗi";
            // 
            // giớiThiệuVềChươngTrìnhToolStripMenuItem
            // 
            this.giớiThiệuVềChươngTrìnhToolStripMenuItem.Name = "giớiThiệuVềChươngTrìnhToolStripMenuItem";
            this.giớiThiệuVềChươngTrìnhToolStripMenuItem.Size = new System.Drawing.Size(256, 22);
            this.giớiThiệuVềChươngTrìnhToolStripMenuItem.Text = "Giới Thiệu Về Chương Trình";
            // 
            // comboBox7
            // 
            this.comboBox7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Location = new System.Drawing.Point(286, 237);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(243, 24);
            this.comboBox7.TabIndex = 46;
            // 
            // comboBox6
            // 
            this.comboBox6.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Location = new System.Drawing.Point(286, 207);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(243, 24);
            this.comboBox6.TabIndex = 47;
            // 
            // comboBox5
            // 
            this.comboBox5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(286, 177);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(243, 24);
            this.comboBox5.TabIndex = 54;
            // 
            // comboBox4
            // 
            this.comboBox4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(286, 147);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(243, 24);
            this.comboBox4.TabIndex = 55;
            // 
            // comboBox3
            // 
            this.comboBox3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(286, 117);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(243, 24);
            this.comboBox3.TabIndex = 53;
            // 
            // comboBox2
            // 
            this.comboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(286, 87);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(243, 24);
            this.comboBox2.TabIndex = 51;
            // 
            // comboBox1
            // 
            this.comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(286, 57);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(243, 24);
            this.comboBox1.TabIndex = 52;
            // 
            // btnReturnHome
            // 
            this.btnReturnHome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReturnHome.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnReturnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReturnHome.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReturnHome.Location = new System.Drawing.Point(155, 293);
            this.btnReturnHome.Name = "btnReturnHome";
            this.btnReturnHome.Size = new System.Drawing.Size(175, 50);
            this.btnReturnHome.TabIndex = 43;
            this.btnReturnHome.Text = "Trở Về Màn Hình Chính";
            this.btnReturnHome.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            this.btnExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExit.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(341, 293);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(188, 50);
            this.btnExit.TabIndex = 44;
            this.btnExit.Text = "Thoát Khỏi Chương Trình";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnRemPro
            // 
            this.btnRemPro.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRemPro.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnRemPro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRemPro.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemPro.Location = new System.Drawing.Point(9, 211);
            this.btnRemPro.Name = "btnRemPro";
            this.btnRemPro.Size = new System.Drawing.Size(140, 50);
            this.btnRemPro.TabIndex = 45;
            this.btnRemPro.Text = "Xóa Sản Phẩm";
            this.btnRemPro.UseVisualStyleBackColor = true;
            // 
            // btnEdiPro
            // 
            this.btnEdiPro.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEdiPro.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnEdiPro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEdiPro.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdiPro.Location = new System.Drawing.Point(9, 148);
            this.btnEdiPro.Name = "btnEdiPro";
            this.btnEdiPro.Size = new System.Drawing.Size(140, 53);
            this.btnEdiPro.TabIndex = 42;
            this.btnEdiPro.Text = "Sửa Sản Phẩm";
            this.btnEdiPro.UseVisualStyleBackColor = true;
            // 
            // btnAddPro
            // 
            this.btnAddPro.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddPro.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnAddPro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddPro.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddPro.Location = new System.Drawing.Point(9, 31);
            this.btnAddPro.Name = "btnAddPro";
            this.btnAddPro.Size = new System.Drawing.Size(140, 50);
            this.btnAddPro.TabIndex = 41;
            this.btnAddPro.Text = "Thêm Sản Phẩm";
            this.btnAddPro.UseVisualStyleBackColor = true;
            // 
            // btnViewPro
            // 
            this.btnViewPro.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnViewPro.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnViewPro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnViewPro.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewPro.Location = new System.Drawing.Point(9, 88);
            this.btnViewPro.Name = "btnViewPro";
            this.btnViewPro.Size = new System.Drawing.Size(140, 53);
            this.btnViewPro.TabIndex = 40;
            this.btnViewPro.Text = "Tra Cứu Sản Phẩm";
            this.btnViewPro.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(286, 28);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(243, 23);
            this.textBox1.TabIndex = 39;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(155, 271);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(125, 16);
            this.label8.TabIndex = 36;
            this.label8.Text = "Mức Đặt Hàng Lại:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblUOO
            // 
            this.lblUOO.AutoSize = true;
            this.lblUOO.Location = new System.Drawing.Point(155, 245);
            this.lblUOO.Name = "lblUOO";
            this.lblUOO.Size = new System.Drawing.Size(75, 16);
            this.lblUOO.TabIndex = 35;
            this.lblUOO.Text = "Đang Bán:";
            this.lblUOO.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblUIS
            // 
            this.lblUIS.AutoSize = true;
            this.lblUIS.Location = new System.Drawing.Point(155, 215);
            this.lblUIS.Name = "lblUIS";
            this.lblUIS.Size = new System.Drawing.Size(66, 16);
            this.lblUIS.TabIndex = 34;
            this.lblUIS.Text = "Tồn Kho:";
            this.lblUIS.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblUniPri
            // 
            this.lblUniPri.AutoSize = true;
            this.lblUniPri.Location = new System.Drawing.Point(155, 185);
            this.lblUniPri.Name = "lblUniPri";
            this.lblUniPri.Size = new System.Drawing.Size(65, 16);
            this.lblUniPri.TabIndex = 33;
            this.lblUniPri.Text = "Đơn Giá:";
            this.lblUniPri.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblQPU
            // 
            this.lblQPU.AutoSize = true;
            this.lblQPU.Location = new System.Drawing.Point(155, 155);
            this.lblQPU.Name = "lblQPU";
            this.lblQPU.Size = new System.Drawing.Size(75, 16);
            this.lblQPU.TabIndex = 32;
            this.lblQPU.Text = "Quy Cách:";
            this.lblQPU.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblProCat
            // 
            this.lblProCat.AutoSize = true;
            this.lblProCat.Location = new System.Drawing.Point(155, 125);
            this.lblProCat.Name = "lblProCat";
            this.lblProCat.Size = new System.Drawing.Size(108, 16);
            this.lblProCat.TabIndex = 31;
            this.lblProCat.Text = "Loại Sản Phẩm:";
            this.lblProCat.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblSuppliers
            // 
            this.lblSuppliers.AutoSize = true;
            this.lblSuppliers.Location = new System.Drawing.Point(155, 95);
            this.lblSuppliers.Name = "lblSuppliers";
            this.lblSuppliers.Size = new System.Drawing.Size(105, 16);
            this.lblSuppliers.TabIndex = 30;
            this.lblSuppliers.Text = "Nhà Cung Cấp:";
            this.lblSuppliers.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblProName
            // 
            this.lblProName.AutoSize = true;
            this.lblProName.Location = new System.Drawing.Point(155, 65);
            this.lblProName.Name = "lblProName";
            this.lblProName.Size = new System.Drawing.Size(106, 16);
            this.lblProName.TabIndex = 29;
            this.lblProName.Text = "Tên Sản Phẩm:";
            this.lblProName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblProID
            // 
            this.lblProID.AutoSize = true;
            this.lblProID.Location = new System.Drawing.Point(155, 35);
            this.lblProID.Name = "lblProID";
            this.lblProID.Size = new System.Drawing.Size(100, 16);
            this.lblProID.TabIndex = 28;
            this.lblProID.Text = "Mã Sản Phẩm:";
            this.lblProID.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(286, 264);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(44, 23);
            this.numericUpDown1.TabIndex = 56;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox1.Location = new System.Drawing.Point(371, 267);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(158, 20);
            this.checkBox1.TabIndex = 57;
            this.checkBox1.Text = "Ngưng Kinh Doanh?";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // fProducts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(538, 351);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.comboBox7);
            this.Controls.Add(this.comboBox6);
            this.Controls.Add(this.comboBox5);
            this.Controls.Add(this.comboBox4);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.btnReturnHome);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnRemPro);
            this.Controls.Add(this.btnEdiPro);
            this.Controls.Add(this.btnAddPro);
            this.Controls.Add(this.btnViewPro);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.lblUOO);
            this.Controls.Add(this.lblUIS);
            this.Controls.Add(this.lblUniPri);
            this.Controls.Add(this.lblQPU);
            this.Controls.Add(this.lblProCat);
            this.Controls.Add(this.lblSuppliers);
            this.Controls.Add(this.lblProName);
            this.Controls.Add(this.lblProID);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "fProducts";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thông Tin Sản Phẩm - Chương Trình Quản Lý Tiệm Cafe";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem thaoTácToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tìmSảnPhẩmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem theoMãToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem theoTênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem theoNgàyCậpNhậtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tùyChọnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xóaSảnPhẩmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sửaThôngTinSảnPhẩmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xóaSảnPhẩmToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem đóngChứcNăngNàyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trợGiúpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem giớiThiệuChứcNăngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tựKhắcPhụcLỗiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem báoCáoLỗiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem giớiThiệuVềChươngTrìnhToolStripMenuItem;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button btnReturnHome;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnRemPro;
        private System.Windows.Forms.Button btnEdiPro;
        private System.Windows.Forms.Button btnAddPro;
        private System.Windows.Forms.Button btnViewPro;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblUOO;
        private System.Windows.Forms.Label lblUIS;
        private System.Windows.Forms.Label lblUniPri;
        private System.Windows.Forms.Label lblQPU;
        private System.Windows.Forms.Label lblProCat;
        private System.Windows.Forms.Label lblSuppliers;
        private System.Windows.Forms.Label lblProName;
        private System.Windows.Forms.Label lblProID;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.CheckBox checkBox1;
    }
}