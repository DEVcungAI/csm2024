﻿namespace DuAnPhanMemQuanLyTiemCafe
{
    partial class fSoftwareManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.tàiKhoảnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kiểmTraThôngTinToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thayĐổiThôngTinToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thayĐổiNgườiDùngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.khôiPhụcDữLiệuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xuấtDữLiệuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nhậpDữLiệuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thoátKhỏiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thoátChươngTrìnhToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chỉnhSửaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.giaoDiệnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hìnhẢnhToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.âmThanhToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.khácToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chứcNăngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trợGiúpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.giớiThiệuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chứcNăngToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.chươngTrìnhToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinPhiênBảnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kiểmTraCậpNhậtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gửiBáoCáoLỗiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yêuCầuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnAccess = new System.Windows.Forms.Button();
            this.btnRecovery = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Arial", 9F);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tàiKhoảnToolStripMenuItem,
            this.chỉnhSửaToolStripMenuItem,
            this.trợGiúpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(632, 25);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // tàiKhoảnToolStripMenuItem
            // 
            this.tàiKhoảnToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kiểmTraThôngTinToolStripMenuItem,
            this.thayĐổiThôngTinToolStripMenuItem,
            this.thayĐổiNgườiDùngToolStripMenuItem,
            this.khôiPhụcDữLiệuToolStripMenuItem,
            this.thoátKhỏiToolStripMenuItem,
            this.thoátChươngTrìnhToolStripMenuItem});
            this.tàiKhoảnToolStripMenuItem.Name = "tàiKhoảnToolStripMenuItem";
            this.tàiKhoảnToolStripMenuItem.Size = new System.Drawing.Size(149, 21);
            this.tàiKhoảnToolStripMenuItem.Text = "Thao Tác Hệ Thống";
            // 
            // kiểmTraThôngTinToolStripMenuItem
            // 
            this.kiểmTraThôngTinToolStripMenuItem.Name = "kiểmTraThôngTinToolStripMenuItem";
            this.kiểmTraThôngTinToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.kiểmTraThôngTinToolStripMenuItem.Text = "Kiểm Tra Thông Tin";
            // 
            // thayĐổiThôngTinToolStripMenuItem
            // 
            this.thayĐổiThôngTinToolStripMenuItem.Name = "thayĐổiThôngTinToolStripMenuItem";
            this.thayĐổiThôngTinToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.thayĐổiThôngTinToolStripMenuItem.Text = "Chỉnh Sửa Thông Tin";
            // 
            // thayĐổiNgườiDùngToolStripMenuItem
            // 
            this.thayĐổiNgườiDùngToolStripMenuItem.Name = "thayĐổiNgườiDùngToolStripMenuItem";
            this.thayĐổiNgườiDùngToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.thayĐổiNgườiDùngToolStripMenuItem.Text = "Thay Đổi Người Dùng";
            // 
            // khôiPhụcDữLiệuToolStripMenuItem
            // 
            this.khôiPhụcDữLiệuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.xuấtDữLiệuToolStripMenuItem,
            this.nhậpDữLiệuToolStripMenuItem});
            this.khôiPhụcDữLiệuToolStripMenuItem.Name = "khôiPhụcDữLiệuToolStripMenuItem";
            this.khôiPhụcDữLiệuToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.khôiPhụcDữLiệuToolStripMenuItem.Text = "Khôi Phục Dữ Liệu";
            // 
            // xuấtDữLiệuToolStripMenuItem
            // 
            this.xuấtDữLiệuToolStripMenuItem.Name = "xuấtDữLiệuToolStripMenuItem";
            this.xuấtDữLiệuToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.xuấtDữLiệuToolStripMenuItem.Text = "Xuất Dữ Liệu";
            // 
            // nhậpDữLiệuToolStripMenuItem
            // 
            this.nhậpDữLiệuToolStripMenuItem.Name = "nhậpDữLiệuToolStripMenuItem";
            this.nhậpDữLiệuToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.nhậpDữLiệuToolStripMenuItem.Text = "Nhập Dữ Liệu";
            // 
            // thoátKhỏiToolStripMenuItem
            // 
            this.thoátKhỏiToolStripMenuItem.Name = "thoátKhỏiToolStripMenuItem";
            this.thoátKhỏiToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.thoátKhỏiToolStripMenuItem.Text = "Đóng Cửa Sổ Đang Chạy";
            // 
            // thoátChươngTrìnhToolStripMenuItem
            // 
            this.thoátChươngTrìnhToolStripMenuItem.Name = "thoátChươngTrìnhToolStripMenuItem";
            this.thoátChươngTrìnhToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.thoátChươngTrìnhToolStripMenuItem.Text = "Thoát Chương Trình";
            this.thoátChươngTrìnhToolStripMenuItem.Click += new System.EventHandler(this.thoátChươngTrìnhToolStripMenuItem_Click);
            // 
            // chỉnhSửaToolStripMenuItem
            // 
            this.chỉnhSửaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.giaoDiệnToolStripMenuItem,
            this.chứcNăngToolStripMenuItem});
            this.chỉnhSửaToolStripMenuItem.Name = "chỉnhSửaToolStripMenuItem";
            this.chỉnhSửaToolStripMenuItem.Size = new System.Drawing.Size(144, 21);
            this.chỉnhSửaToolStripMenuItem.Text = "Thiết Lập Cấu Hình";
            // 
            // giaoDiệnToolStripMenuItem
            // 
            this.giaoDiệnToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hìnhẢnhToolStripMenuItem,
            this.âmThanhToolStripMenuItem,
            this.khácToolStripMenuItem});
            this.giaoDiệnToolStripMenuItem.Name = "giaoDiệnToolStripMenuItem";
            this.giaoDiệnToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.giaoDiệnToolStripMenuItem.Text = "Hệ Thống";
            // 
            // hìnhẢnhToolStripMenuItem
            // 
            this.hìnhẢnhToolStripMenuItem.Name = "hìnhẢnhToolStripMenuItem";
            this.hìnhẢnhToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.hìnhẢnhToolStripMenuItem.Text = "Hình Ảnh";
            // 
            // âmThanhToolStripMenuItem
            // 
            this.âmThanhToolStripMenuItem.Name = "âmThanhToolStripMenuItem";
            this.âmThanhToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.âmThanhToolStripMenuItem.Text = "Âm Thanh";
            // 
            // khácToolStripMenuItem
            // 
            this.khácToolStripMenuItem.Name = "khácToolStripMenuItem";
            this.khácToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.khácToolStripMenuItem.Text = "Khác";
            // 
            // chứcNăngToolStripMenuItem
            // 
            this.chứcNăngToolStripMenuItem.Name = "chứcNăngToolStripMenuItem";
            this.chứcNăngToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.chứcNăngToolStripMenuItem.Text = "Chức Năng";
            // 
            // trợGiúpToolStripMenuItem
            // 
            this.trợGiúpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.giớiThiệuToolStripMenuItem,
            this.thôngTinPhiênBảnToolStripMenuItem,
            this.gửiBáoCáoLỗiToolStripMenuItem,
            this.yêuCầuToolStripMenuItem});
            this.trợGiúpToolStripMenuItem.Name = "trợGiúpToolStripMenuItem";
            this.trợGiúpToolStripMenuItem.Size = new System.Drawing.Size(77, 21);
            this.trợGiúpToolStripMenuItem.Text = "Trợ Giúp";
            // 
            // giớiThiệuToolStripMenuItem
            // 
            this.giớiThiệuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.chứcNăngToolStripMenuItem1,
            this.chươngTrìnhToolStripMenuItem});
            this.giớiThiệuToolStripMenuItem.Name = "giớiThiệuToolStripMenuItem";
            this.giớiThiệuToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
            this.giớiThiệuToolStripMenuItem.Text = "Giới Thiệu";
            // 
            // chứcNăngToolStripMenuItem1
            // 
            this.chứcNăngToolStripMenuItem1.Name = "chứcNăngToolStripMenuItem1";
            this.chứcNăngToolStripMenuItem1.Size = new System.Drawing.Size(167, 22);
            this.chứcNăngToolStripMenuItem1.Text = "Chức Năng";
            // 
            // chươngTrìnhToolStripMenuItem
            // 
            this.chươngTrìnhToolStripMenuItem.Name = "chươngTrìnhToolStripMenuItem";
            this.chươngTrìnhToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.chươngTrìnhToolStripMenuItem.Text = "Chương Trình";
            // 
            // thôngTinPhiênBảnToolStripMenuItem
            // 
            this.thôngTinPhiênBảnToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kiểmTraCậpNhậtToolStripMenuItem});
            this.thôngTinPhiênBảnToolStripMenuItem.Name = "thôngTinPhiênBảnToolStripMenuItem";
            this.thôngTinPhiênBảnToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
            this.thôngTinPhiênBảnToolStripMenuItem.Text = "Thông Tin Phiên Bản";
            // 
            // kiểmTraCậpNhậtToolStripMenuItem
            // 
            this.kiểmTraCậpNhậtToolStripMenuItem.Name = "kiểmTraCậpNhậtToolStripMenuItem";
            this.kiểmTraCậpNhậtToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.kiểmTraCậpNhậtToolStripMenuItem.Text = "Kiểm Tra Cập Nhật";
            // 
            // gửiBáoCáoLỗiToolStripMenuItem
            // 
            this.gửiBáoCáoLỗiToolStripMenuItem.Name = "gửiBáoCáoLỗiToolStripMenuItem";
            this.gửiBáoCáoLỗiToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
            this.gửiBáoCáoLỗiToolStripMenuItem.Text = "Gửi Báo Cáo Lỗi";
            // 
            // yêuCầuToolStripMenuItem
            // 
            this.yêuCầuToolStripMenuItem.Name = "yêuCầuToolStripMenuItem";
            this.yêuCầuToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
            this.yêuCầuToolStripMenuItem.Text = "Yêu Cầu Chức Năng";
            // 
            // btnAccess
            // 
            this.btnAccess.BackColor = System.Drawing.Color.Yellow;
            this.btnAccess.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAccess.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnAccess.FlatAppearance.BorderSize = 0;
            this.btnAccess.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAccess.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.btnAccess.Location = new System.Drawing.Point(12, 49);
            this.btnAccess.Name = "btnAccess";
            this.btnAccess.Size = new System.Drawing.Size(300, 170);
            this.btnAccess.TabIndex = 1;
            this.btnAccess.Text = "Trích Xuất Thông Tin";
            this.btnAccess.UseVisualStyleBackColor = false;
            this.btnAccess.Click += new System.EventHandler(this.btnAccess_Click);
            // 
            // btnRecovery
            // 
            this.btnRecovery.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnRecovery.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRecovery.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnRecovery.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRecovery.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.btnRecovery.ForeColor = System.Drawing.Color.White;
            this.btnRecovery.Location = new System.Drawing.Point(320, 49);
            this.btnRecovery.Name = "btnRecovery";
            this.btnRecovery.Size = new System.Drawing.Size(300, 170);
            this.btnRecovery.TabIndex = 1;
            this.btnRecovery.Text = "Khôi Phục Dữ Liệu";
            this.btnRecovery.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Arial", 10F);
            this.button3.Location = new System.Drawing.Point(14, 245);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(300, 170);
            this.button3.TabIndex = 1;
            this.button3.Text = "Thiết Lập Cấu Hình";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExit.FlatAppearance.BorderSize = 0;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.btnExit.ForeColor = System.Drawing.Color.LightGray;
            this.btnExit.Location = new System.Drawing.Point(320, 245);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(300, 170);
            this.btnExit.TabIndex = 1;
            this.btnExit.Text = "Thoát Chương Trình";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.button4_Click);
            // 
            // fSoftwareManagement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(632, 448);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.btnRecovery);
            this.Controls.Add(this.btnAccess);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "fSoftwareManagement";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Chương Trình Quản Lý Tiệm Cafe";
            this.Load += new System.EventHandler(this.fSoftwareManagement_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem tàiKhoảnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chỉnhSửaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trợGiúpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem giớiThiệuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thôngTinPhiênBảnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gửiBáoCáoLỗiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yêuCầuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kiểmTraThôngTinToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thayĐổiThôngTinToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thayĐổiNgườiDùngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thoátKhỏiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thoátChươngTrìnhToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem giaoDiệnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hìnhẢnhToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem âmThanhToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem khácToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kiểmTraCậpNhậtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chứcNăngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem khôiPhụcDữLiệuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xuấtDữLiệuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nhậpDữLiệuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chứcNăngToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem chươngTrìnhToolStripMenuItem;
        private System.Windows.Forms.Button btnAccess;
        private System.Windows.Forms.Button btnRecovery;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btnExit;
    }
}

