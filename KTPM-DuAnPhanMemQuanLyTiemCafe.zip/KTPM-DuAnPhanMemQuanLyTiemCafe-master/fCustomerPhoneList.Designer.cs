﻿namespace DuAnPhanMemQuanLyTiemCafe
{
    partial class fCustomerPhoneList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.thaoTácToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tìmSảnPhẩmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.theoMãToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.theoTênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.theoNgàyCậpNhậtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tùyChọnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xóaSảnPhẩmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sửaThôngTinSảnPhẩmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xóaSảnPhẩmToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.đóngChứcNăngNàyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trợGiúpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.giớiThiệuChứcNăngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tựKhắcPhụcLỗiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.báoCáoLỗiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.giớiThiệuVềChươngTrìnhToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(107, 148);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(790, 35);
            this.label1.TabIndex = 3;
            this.label1.Text = "Xin Lỗi, Chức Năng Này Đang Trong Giai Đoạn Bảo Trì.";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Bisque;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Arial", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Pixel);
            this.button1.ForeColor = System.Drawing.Color.Blue;
            this.button1.Location = new System.Drawing.Point(762, 239);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(234, 100);
            this.button1.TabIndex = 4;
            this.button1.Text = "Thoát Chương Trình";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Arial", 7.8F);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thaoTácToolStripMenuItem,
            this.trợGiúpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1008, 24);
            this.menuStrip1.TabIndex = 87;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // thaoTácToolStripMenuItem
            // 
            this.thaoTácToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tìmSảnPhẩmToolStripMenuItem,
            this.xóaSảnPhẩmToolStripMenuItem,
            this.sửaThôngTinSảnPhẩmToolStripMenuItem,
            this.xóaSảnPhẩmToolStripMenuItem1,
            this.đóngChứcNăngNàyToolStripMenuItem});
            this.thaoTácToolStripMenuItem.Font = new System.Drawing.Font("Arial", 7.8F);
            this.thaoTácToolStripMenuItem.Name = "thaoTácToolStripMenuItem";
            this.thaoTácToolStripMenuItem.Size = new System.Drawing.Size(81, 20);
            this.thaoTácToolStripMenuItem.Text = "Thao Tác";
            // 
            // tìmSảnPhẩmToolStripMenuItem
            // 
            this.tìmSảnPhẩmToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.theoMãToolStripMenuItem,
            this.theoTênToolStripMenuItem,
            this.theoNgàyCậpNhậtToolStripMenuItem,
            this.tùyChọnToolStripMenuItem});
            this.tìmSảnPhẩmToolStripMenuItem.Font = new System.Drawing.Font("Arial", 7.8F);
            this.tìmSảnPhẩmToolStripMenuItem.Name = "tìmSảnPhẩmToolStripMenuItem";
            this.tìmSảnPhẩmToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.tìmSảnPhẩmToolStripMenuItem.Text = "Tìm Sản Phẩm";
            // 
            // theoMãToolStripMenuItem
            // 
            this.theoMãToolStripMenuItem.Font = new System.Drawing.Font("Arial", 7.8F);
            this.theoMãToolStripMenuItem.Name = "theoMãToolStripMenuItem";
            this.theoMãToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.theoMãToolStripMenuItem.Text = "Theo Mã";
            // 
            // theoTênToolStripMenuItem
            // 
            this.theoTênToolStripMenuItem.Font = new System.Drawing.Font("Arial", 7.8F);
            this.theoTênToolStripMenuItem.Name = "theoTênToolStripMenuItem";
            this.theoTênToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.theoTênToolStripMenuItem.Text = "Theo Tên";
            // 
            // theoNgàyCậpNhậtToolStripMenuItem
            // 
            this.theoNgàyCậpNhậtToolStripMenuItem.Font = new System.Drawing.Font("Arial", 7.8F);
            this.theoNgàyCậpNhậtToolStripMenuItem.Name = "theoNgàyCậpNhậtToolStripMenuItem";
            this.theoNgàyCậpNhậtToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.theoNgàyCậpNhậtToolStripMenuItem.Text = "Theo Ngày Cập Nhật";
            // 
            // tùyChọnToolStripMenuItem
            // 
            this.tùyChọnToolStripMenuItem.Font = new System.Drawing.Font("Arial", 7.8F);
            this.tùyChọnToolStripMenuItem.Name = "tùyChọnToolStripMenuItem";
            this.tùyChọnToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.tùyChọnToolStripMenuItem.Text = "Tùy Chọn";
            // 
            // xóaSảnPhẩmToolStripMenuItem
            // 
            this.xóaSảnPhẩmToolStripMenuItem.Font = new System.Drawing.Font("Arial", 7.8F);
            this.xóaSảnPhẩmToolStripMenuItem.Name = "xóaSảnPhẩmToolStripMenuItem";
            this.xóaSảnPhẩmToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.xóaSảnPhẩmToolStripMenuItem.Text = "Thêm Sản Phẩm";
            // 
            // sửaThôngTinSảnPhẩmToolStripMenuItem
            // 
            this.sửaThôngTinSảnPhẩmToolStripMenuItem.Font = new System.Drawing.Font("Arial", 7.8F);
            this.sửaThôngTinSảnPhẩmToolStripMenuItem.Name = "sửaThôngTinSảnPhẩmToolStripMenuItem";
            this.sửaThôngTinSảnPhẩmToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.sửaThôngTinSảnPhẩmToolStripMenuItem.Text = "Sửa Thông Tin Sản Phẩm";
            // 
            // xóaSảnPhẩmToolStripMenuItem1
            // 
            this.xóaSảnPhẩmToolStripMenuItem1.Font = new System.Drawing.Font("Arial", 7.8F);
            this.xóaSảnPhẩmToolStripMenuItem1.Name = "xóaSảnPhẩmToolStripMenuItem1";
            this.xóaSảnPhẩmToolStripMenuItem1.Size = new System.Drawing.Size(239, 22);
            this.xóaSảnPhẩmToolStripMenuItem1.Text = "Xóa Sản Phẩm";
            // 
            // đóngChứcNăngNàyToolStripMenuItem
            // 
            this.đóngChứcNăngNàyToolStripMenuItem.Font = new System.Drawing.Font("Arial", 7.8F);
            this.đóngChứcNăngNàyToolStripMenuItem.Name = "đóngChứcNăngNàyToolStripMenuItem";
            this.đóngChứcNăngNàyToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.đóngChứcNăngNàyToolStripMenuItem.Text = "Đóng Chức Năng Này";
            // 
            // trợGiúpToolStripMenuItem
            // 
            this.trợGiúpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.giớiThiệuChứcNăngToolStripMenuItem,
            this.tựKhắcPhụcLỗiToolStripMenuItem,
            this.báoCáoLỗiToolStripMenuItem,
            this.giớiThiệuVềChươngTrìnhToolStripMenuItem});
            this.trợGiúpToolStripMenuItem.Font = new System.Drawing.Font("Arial", 7.8F);
            this.trợGiúpToolStripMenuItem.Name = "trợGiúpToolStripMenuItem";
            this.trợGiúpToolStripMenuItem.Size = new System.Drawing.Size(76, 20);
            this.trợGiúpToolStripMenuItem.Text = "Trợ Giúp";
            // 
            // giớiThiệuChứcNăngToolStripMenuItem
            // 
            this.giớiThiệuChứcNăngToolStripMenuItem.Font = new System.Drawing.Font("Arial", 7.8F);
            this.giớiThiệuChứcNăngToolStripMenuItem.Name = "giớiThiệuChứcNăngToolStripMenuItem";
            this.giớiThiệuChứcNăngToolStripMenuItem.Size = new System.Drawing.Size(256, 22);
            this.giớiThiệuChứcNăngToolStripMenuItem.Text = "Giới Thiệu Chức Năng";
            // 
            // tựKhắcPhụcLỗiToolStripMenuItem
            // 
            this.tựKhắcPhụcLỗiToolStripMenuItem.Font = new System.Drawing.Font("Arial", 7.8F);
            this.tựKhắcPhụcLỗiToolStripMenuItem.Name = "tựKhắcPhụcLỗiToolStripMenuItem";
            this.tựKhắcPhụcLỗiToolStripMenuItem.Size = new System.Drawing.Size(256, 22);
            this.tựKhắcPhụcLỗiToolStripMenuItem.Text = "Tự Khắc Phục Lỗi";
            // 
            // báoCáoLỗiToolStripMenuItem
            // 
            this.báoCáoLỗiToolStripMenuItem.Font = new System.Drawing.Font("Arial", 7.8F);
            this.báoCáoLỗiToolStripMenuItem.Name = "báoCáoLỗiToolStripMenuItem";
            this.báoCáoLỗiToolStripMenuItem.Size = new System.Drawing.Size(256, 22);
            this.báoCáoLỗiToolStripMenuItem.Text = "Báo Cáo Lỗi";
            // 
            // giớiThiệuVềChươngTrìnhToolStripMenuItem
            // 
            this.giớiThiệuVềChươngTrìnhToolStripMenuItem.Font = new System.Drawing.Font("Arial", 7.8F);
            this.giớiThiệuVềChươngTrìnhToolStripMenuItem.Name = "giớiThiệuVềChươngTrìnhToolStripMenuItem";
            this.giớiThiệuVềChươngTrìnhToolStripMenuItem.Size = new System.Drawing.Size(256, 22);
            this.giớiThiệuVềChươngTrìnhToolStripMenuItem.Text = "Giới Thiệu Về Chương Trình";
            // 
            // fCustomerPhoneList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(4F, 10F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1008, 351);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "fCustomerPhoneList";
            this.Text = "Danh Sách Số Điện Thoại Khách Hàng - Chương Trình Quản Lý Tiệm Cafe";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem thaoTácToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tìmSảnPhẩmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem theoMãToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem theoTênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem theoNgàyCậpNhậtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tùyChọnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xóaSảnPhẩmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sửaThôngTinSảnPhẩmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xóaSảnPhẩmToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem đóngChứcNăngNàyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trợGiúpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem giớiThiệuChứcNăngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tựKhắcPhụcLỗiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem báoCáoLỗiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem giớiThiệuVềChươngTrìnhToolStripMenuItem;
    }
}