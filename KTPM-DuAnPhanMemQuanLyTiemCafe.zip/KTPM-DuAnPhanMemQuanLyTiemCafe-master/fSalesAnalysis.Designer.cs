﻿namespace DuAnPhanMemQuanLyTiemCafe
{
    partial class fSalesAnalysis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.thaoTácToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trợGiúpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thốngKêToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mặcĐịnhToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.theoThángToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.theoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.theoThángToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.theoQuýToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.theoNămToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tùyChọnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xuấtBáoCáoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pDFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vănBảnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dOCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dOCXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trangTínhToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xLSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xLSXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iMGToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jPGToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pNGToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gIFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đóngCửaSổNàyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thoátChươngTrìnhToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.giớiThiệuChứcNăngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.báoCáoLỗiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thaoTácToolStripMenuItem,
            this.trợGiúpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(561, 26);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // thaoTácToolStripMenuItem
            // 
            this.thaoTácToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thốngKêToolStripMenuItem,
            this.xuấtBáoCáoToolStripMenuItem,
            this.đóngCửaSổNàyToolStripMenuItem,
            this.thoátChươngTrìnhToolStripMenuItem});
            this.thaoTácToolStripMenuItem.Name = "thaoTácToolStripMenuItem";
            this.thaoTácToolStripMenuItem.Size = new System.Drawing.Size(84, 22);
            this.thaoTácToolStripMenuItem.Text = "Thao Tác";
            // 
            // trợGiúpToolStripMenuItem
            // 
            this.trợGiúpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.giớiThiệuChứcNăngToolStripMenuItem,
            this.báoCáoLỗiToolStripMenuItem});
            this.trợGiúpToolStripMenuItem.Name = "trợGiúpToolStripMenuItem";
            this.trợGiúpToolStripMenuItem.Size = new System.Drawing.Size(76, 22);
            this.trợGiúpToolStripMenuItem.Text = "Trợ Giúp";
            // 
            // thốngKêToolStripMenuItem
            // 
            this.thốngKêToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mặcĐịnhToolStripMenuItem,
            this.theoThángToolStripMenuItem,
            this.theoToolStripMenuItem,
            this.theoThángToolStripMenuItem1,
            this.theoQuýToolStripMenuItem,
            this.theoNămToolStripMenuItem,
            this.tùyChọnToolStripMenuItem});
            this.thốngKêToolStripMenuItem.Name = "thốngKêToolStripMenuItem";
            this.thốngKêToolStripMenuItem.Size = new System.Drawing.Size(218, 22);
            this.thốngKêToolStripMenuItem.Text = "Thống Kê";
            // 
            // mặcĐịnhToolStripMenuItem
            // 
            this.mặcĐịnhToolStripMenuItem.Name = "mặcĐịnhToolStripMenuItem";
            this.mặcĐịnhToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.mặcĐịnhToolStripMenuItem.Text = "Mặc Định";
            // 
            // theoThángToolStripMenuItem
            // 
            this.theoThángToolStripMenuItem.Name = "theoThángToolStripMenuItem";
            this.theoThángToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.theoThángToolStripMenuItem.Text = "Theo Ngày";
            // 
            // theoToolStripMenuItem
            // 
            this.theoToolStripMenuItem.Name = "theoToolStripMenuItem";
            this.theoToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.theoToolStripMenuItem.Text = "Theo Tuần";
            // 
            // theoThángToolStripMenuItem1
            // 
            this.theoThángToolStripMenuItem1.Name = "theoThángToolStripMenuItem1";
            this.theoThángToolStripMenuItem1.Size = new System.Drawing.Size(157, 22);
            this.theoThángToolStripMenuItem1.Text = "Theo Tháng";
            // 
            // theoQuýToolStripMenuItem
            // 
            this.theoQuýToolStripMenuItem.Name = "theoQuýToolStripMenuItem";
            this.theoQuýToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.theoQuýToolStripMenuItem.Text = "Theo Quý";
            // 
            // theoNămToolStripMenuItem
            // 
            this.theoNămToolStripMenuItem.Name = "theoNămToolStripMenuItem";
            this.theoNămToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.theoNămToolStripMenuItem.Text = "Theo Năm";
            // 
            // tùyChọnToolStripMenuItem
            // 
            this.tùyChọnToolStripMenuItem.Name = "tùyChọnToolStripMenuItem";
            this.tùyChọnToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.tùyChọnToolStripMenuItem.Text = "Tùy Chọn";
            // 
            // xuấtBáoCáoToolStripMenuItem
            // 
            this.xuấtBáoCáoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pDFToolStripMenuItem,
            this.vănBảnToolStripMenuItem,
            this.trangTínhToolStripMenuItem,
            this.iMGToolStripMenuItem});
            this.xuấtBáoCáoToolStripMenuItem.Name = "xuấtBáoCáoToolStripMenuItem";
            this.xuấtBáoCáoToolStripMenuItem.Size = new System.Drawing.Size(218, 22);
            this.xuấtBáoCáoToolStripMenuItem.Text = "Xuất Báo Cáo";
            // 
            // pDFToolStripMenuItem
            // 
            this.pDFToolStripMenuItem.Name = "pDFToolStripMenuItem";
            this.pDFToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.pDFToolStripMenuItem.Text = "PDF";
            // 
            // vănBảnToolStripMenuItem
            // 
            this.vănBảnToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dOCToolStripMenuItem,
            this.dOCXToolStripMenuItem});
            this.vănBảnToolStripMenuItem.Name = "vănBảnToolStripMenuItem";
            this.vănBảnToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.vănBảnToolStripMenuItem.Text = "Văn Bản";
            // 
            // dOCToolStripMenuItem
            // 
            this.dOCToolStripMenuItem.Name = "dOCToolStripMenuItem";
            this.dOCToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.dOCToolStripMenuItem.Text = "DOC";
            // 
            // dOCXToolStripMenuItem
            // 
            this.dOCXToolStripMenuItem.Name = "dOCXToolStripMenuItem";
            this.dOCXToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.dOCXToolStripMenuItem.Text = "DOCX";
            // 
            // trangTínhToolStripMenuItem
            // 
            this.trangTínhToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.xLSToolStripMenuItem,
            this.xLSXToolStripMenuItem});
            this.trangTínhToolStripMenuItem.Name = "trangTínhToolStripMenuItem";
            this.trangTínhToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.trangTínhToolStripMenuItem.Text = "Trang Tính";
            // 
            // xLSToolStripMenuItem
            // 
            this.xLSToolStripMenuItem.Name = "xLSToolStripMenuItem";
            this.xLSToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.xLSToolStripMenuItem.Text = "XLS";
            // 
            // xLSXToolStripMenuItem
            // 
            this.xLSXToolStripMenuItem.Name = "xLSXToolStripMenuItem";
            this.xLSXToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.xLSXToolStripMenuItem.Text = "XLSX";
            // 
            // iMGToolStripMenuItem
            // 
            this.iMGToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.jPGToolStripMenuItem,
            this.pNGToolStripMenuItem,
            this.gIFToolStripMenuItem});
            this.iMGToolStripMenuItem.Name = "iMGToolStripMenuItem";
            this.iMGToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.iMGToolStripMenuItem.Text = "Hình Ảnh";
            // 
            // jPGToolStripMenuItem
            // 
            this.jPGToolStripMenuItem.Name = "jPGToolStripMenuItem";
            this.jPGToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.jPGToolStripMenuItem.Text = "JPG";
            // 
            // pNGToolStripMenuItem
            // 
            this.pNGToolStripMenuItem.Name = "pNGToolStripMenuItem";
            this.pNGToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.pNGToolStripMenuItem.Text = "PNG";
            // 
            // gIFToolStripMenuItem
            // 
            this.gIFToolStripMenuItem.Name = "gIFToolStripMenuItem";
            this.gIFToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.gIFToolStripMenuItem.Text = "GIF";
            // 
            // đóngCửaSổNàyToolStripMenuItem
            // 
            this.đóngCửaSổNàyToolStripMenuItem.Name = "đóngCửaSổNàyToolStripMenuItem";
            this.đóngCửaSổNàyToolStripMenuItem.Size = new System.Drawing.Size(218, 22);
            this.đóngCửaSổNàyToolStripMenuItem.Text = "Đóng Chức Năng Này";
            // 
            // thoátChươngTrìnhToolStripMenuItem
            // 
            this.thoátChươngTrìnhToolStripMenuItem.Name = "thoátChươngTrìnhToolStripMenuItem";
            this.thoátChươngTrìnhToolStripMenuItem.Size = new System.Drawing.Size(218, 22);
            this.thoátChươngTrìnhToolStripMenuItem.Text = "Thoát Chương Trình";
            // 
            // giớiThiệuChứcNăngToolStripMenuItem
            // 
            this.giớiThiệuChứcNăngToolStripMenuItem.Name = "giớiThiệuChứcNăngToolStripMenuItem";
            this.giớiThiệuChứcNăngToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.giớiThiệuChứcNăngToolStripMenuItem.Text = "Giới Thiệu Chức Năng";
            // 
            // báoCáoLỗiToolStripMenuItem
            // 
            this.báoCáoLỗiToolStripMenuItem.Name = "báoCáoLỗiToolStripMenuItem";
            this.báoCáoLỗiToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.báoCáoLỗiToolStripMenuItem.Text = "Báo Cáo Lỗi";
            // 
            // fSalesAnalysis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(561, 342);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "fSalesAnalysis";
            this.Text = "Thống Kê Doanh Số - Chương Trình Quản Lý Tiệm Cafe";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem thaoTácToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thốngKêToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mặcĐịnhToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem theoThángToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem theoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem theoThángToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem theoQuýToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem theoNămToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tùyChọnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xuấtBáoCáoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pDFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vănBảnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dOCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dOCXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trangTínhToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xLSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xLSXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iMGToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jPGToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pNGToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gIFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đóngCửaSổNàyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thoátChươngTrìnhToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trợGiúpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem giớiThiệuChứcNăngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem báoCáoLỗiToolStripMenuItem;
    }
}