﻿namespace DuAnPhanMemQuanLyTiemCafe
{
    partial class fCategories
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.thaoTácToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tìmSảnPhẩmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.theoMãToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.theoTênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.theoNgàyCậpNhậtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tùyChọnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xóaSảnPhẩmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sửaThôngTinSảnPhẩmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xóaSảnPhẩmToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.đóngChứcNăngNàyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trợGiúpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.giớiThiệuChứcNăngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tựKhắcPhụcLỗiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.báoCáoLỗiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.giớiThiệuVềChươngTrìnhToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnReturnHome = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnRemCat = new System.Windows.Forms.Button();
            this.btnEdiCat = new System.Windows.Forms.Button();
            this.btnAddCat = new System.Windows.Forms.Button();
            this.btnViewCat = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblCateDes = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.dgvSupplier = new System.Windows.Forms.DataGridView();
            this.IdColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NameColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AddressColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DelColumn = new System.Windows.Forms.DataGridViewButtonColumn();
            this.EditColumn = new System.Windows.Forms.DataGridViewButtonColumn();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSupplier)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thaoTácToolStripMenuItem,
            this.trợGiúpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1328, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // thaoTácToolStripMenuItem
            // 
            this.thaoTácToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tìmSảnPhẩmToolStripMenuItem,
            this.xóaSảnPhẩmToolStripMenuItem,
            this.sửaThôngTinSảnPhẩmToolStripMenuItem,
            this.xóaSảnPhẩmToolStripMenuItem1,
            this.đóngChứcNăngNàyToolStripMenuItem});
            this.thaoTácToolStripMenuItem.Font = new System.Drawing.Font("Arial", 8F);
            this.thaoTácToolStripMenuItem.Name = "thaoTácToolStripMenuItem";
            this.thaoTácToolStripMenuItem.Size = new System.Drawing.Size(81, 20);
            this.thaoTácToolStripMenuItem.Text = "Thao Tác";
            // 
            // tìmSảnPhẩmToolStripMenuItem
            // 
            this.tìmSảnPhẩmToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.theoMãToolStripMenuItem,
            this.theoTênToolStripMenuItem,
            this.theoNgàyCậpNhậtToolStripMenuItem,
            this.tùyChọnToolStripMenuItem});
            this.tìmSảnPhẩmToolStripMenuItem.Name = "tìmSảnPhẩmToolStripMenuItem";
            this.tìmSảnPhẩmToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.tìmSảnPhẩmToolStripMenuItem.Text = "Tìm Loại Sản Phẩm";
            // 
            // theoMãToolStripMenuItem
            // 
            this.theoMãToolStripMenuItem.Name = "theoMãToolStripMenuItem";
            this.theoMãToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.theoMãToolStripMenuItem.Text = "Theo Mã";
            // 
            // theoTênToolStripMenuItem
            // 
            this.theoTênToolStripMenuItem.Name = "theoTênToolStripMenuItem";
            this.theoTênToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.theoTênToolStripMenuItem.Text = "Theo Tên";
            // 
            // theoNgàyCậpNhậtToolStripMenuItem
            // 
            this.theoNgàyCậpNhậtToolStripMenuItem.Name = "theoNgàyCậpNhậtToolStripMenuItem";
            this.theoNgàyCậpNhậtToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.theoNgàyCậpNhậtToolStripMenuItem.Text = "Theo Ngày Cập Nhật";
            // 
            // tùyChọnToolStripMenuItem
            // 
            this.tùyChọnToolStripMenuItem.Name = "tùyChọnToolStripMenuItem";
            this.tùyChọnToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.tùyChọnToolStripMenuItem.Text = "Tùy Chọn";
            // 
            // xóaSảnPhẩmToolStripMenuItem
            // 
            this.xóaSảnPhẩmToolStripMenuItem.Name = "xóaSảnPhẩmToolStripMenuItem";
            this.xóaSảnPhẩmToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.xóaSảnPhẩmToolStripMenuItem.Text = "Thêm Loại Sản Phẩm";
            // 
            // sửaThôngTinSảnPhẩmToolStripMenuItem
            // 
            this.sửaThôngTinSảnPhẩmToolStripMenuItem.Name = "sửaThôngTinSảnPhẩmToolStripMenuItem";
            this.sửaThôngTinSảnPhẩmToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.sửaThôngTinSảnPhẩmToolStripMenuItem.Text = "Sửa Loại Sản Phẩm";
            // 
            // xóaSảnPhẩmToolStripMenuItem1
            // 
            this.xóaSảnPhẩmToolStripMenuItem1.Name = "xóaSảnPhẩmToolStripMenuItem1";
            this.xóaSảnPhẩmToolStripMenuItem1.Size = new System.Drawing.Size(213, 22);
            this.xóaSảnPhẩmToolStripMenuItem1.Text = "Xóa Loại Sản Phẩm";
            // 
            // đóngChứcNăngNàyToolStripMenuItem
            // 
            this.đóngChứcNăngNàyToolStripMenuItem.Name = "đóngChứcNăngNàyToolStripMenuItem";
            this.đóngChứcNăngNàyToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.đóngChứcNăngNàyToolStripMenuItem.Text = "Đóng Chức Năng Này";
            this.đóngChứcNăngNàyToolStripMenuItem.Click += new System.EventHandler(this.đóngChứcNăngNàyToolStripMenuItem_Click);
            // 
            // trợGiúpToolStripMenuItem
            // 
            this.trợGiúpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.giớiThiệuChứcNăngToolStripMenuItem,
            this.tựKhắcPhụcLỗiToolStripMenuItem,
            this.báoCáoLỗiToolStripMenuItem,
            this.giớiThiệuVềChươngTrìnhToolStripMenuItem});
            this.trợGiúpToolStripMenuItem.Font = new System.Drawing.Font("Arial", 8F);
            this.trợGiúpToolStripMenuItem.Name = "trợGiúpToolStripMenuItem";
            this.trợGiúpToolStripMenuItem.Size = new System.Drawing.Size(76, 20);
            this.trợGiúpToolStripMenuItem.Text = "Trợ Giúp";
            // 
            // giớiThiệuChứcNăngToolStripMenuItem
            // 
            this.giớiThiệuChứcNăngToolStripMenuItem.Name = "giớiThiệuChứcNăngToolStripMenuItem";
            this.giớiThiệuChứcNăngToolStripMenuItem.Size = new System.Drawing.Size(256, 22);
            this.giớiThiệuChứcNăngToolStripMenuItem.Text = "Giới Thiệu Chức Năng";
            // 
            // tựKhắcPhụcLỗiToolStripMenuItem
            // 
            this.tựKhắcPhụcLỗiToolStripMenuItem.Name = "tựKhắcPhụcLỗiToolStripMenuItem";
            this.tựKhắcPhụcLỗiToolStripMenuItem.Size = new System.Drawing.Size(256, 22);
            this.tựKhắcPhụcLỗiToolStripMenuItem.Text = "Tự Khắc Phục Lỗi";
            // 
            // báoCáoLỗiToolStripMenuItem
            // 
            this.báoCáoLỗiToolStripMenuItem.Name = "báoCáoLỗiToolStripMenuItem";
            this.báoCáoLỗiToolStripMenuItem.Size = new System.Drawing.Size(256, 22);
            this.báoCáoLỗiToolStripMenuItem.Text = "Báo Cáo Lỗi";
            // 
            // giớiThiệuVềChươngTrìnhToolStripMenuItem
            // 
            this.giớiThiệuVềChươngTrìnhToolStripMenuItem.Name = "giớiThiệuVềChươngTrìnhToolStripMenuItem";
            this.giớiThiệuVềChươngTrìnhToolStripMenuItem.Size = new System.Drawing.Size(256, 22);
            this.giớiThiệuVềChươngTrìnhToolStripMenuItem.Text = "Giới Thiệu Về Chương Trình";
            // 
            // btnReturnHome
            // 
            this.btnReturnHome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReturnHome.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnReturnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReturnHome.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReturnHome.Location = new System.Drawing.Point(916, 290);
            this.btnReturnHome.Name = "btnReturnHome";
            this.btnReturnHome.Size = new System.Drawing.Size(203, 50);
            this.btnReturnHome.TabIndex = 71;
            this.btnReturnHome.Text = "Trở Về Màn Hình Chính";
            this.btnReturnHome.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            this.btnExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExit.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(1125, 290);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(203, 50);
            this.btnExit.TabIndex = 72;
            this.btnExit.Text = "Thoát Khỏi Chương Trình";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnRemCat
            // 
            this.btnRemCat.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRemCat.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnRemCat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRemCat.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemCat.Location = new System.Drawing.Point(707, 290);
            this.btnRemCat.Name = "btnRemCat";
            this.btnRemCat.Size = new System.Drawing.Size(203, 50);
            this.btnRemCat.TabIndex = 73;
            this.btnRemCat.Text = "Xóa Loại Sản Phẩm";
            this.btnRemCat.UseVisualStyleBackColor = true;
            // 
            // btnEdiCat
            // 
            this.btnEdiCat.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEdiCat.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnEdiCat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEdiCat.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdiCat.Location = new System.Drawing.Point(498, 290);
            this.btnEdiCat.Name = "btnEdiCat";
            this.btnEdiCat.Size = new System.Drawing.Size(203, 50);
            this.btnEdiCat.TabIndex = 70;
            this.btnEdiCat.Text = "Sửa Loại Sản Phẩm";
            this.btnEdiCat.UseVisualStyleBackColor = true;
            // 
            // btnAddCat
            // 
            this.btnAddCat.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddCat.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnAddCat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddCat.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddCat.Location = new System.Drawing.Point(80, 289);
            this.btnAddCat.Name = "btnAddCat";
            this.btnAddCat.Size = new System.Drawing.Size(203, 50);
            this.btnAddCat.TabIndex = 69;
            this.btnAddCat.Text = "Thêm Loại Sản Phẩm";
            this.btnAddCat.UseVisualStyleBackColor = true;
            // 
            // btnViewCat
            // 
            this.btnViewCat.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnViewCat.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnViewCat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnViewCat.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewCat.Location = new System.Drawing.Point(289, 289);
            this.btnViewCat.Name = "btnViewCat";
            this.btnViewCat.Size = new System.Drawing.Size(203, 50);
            this.btnViewCat.TabIndex = 68;
            this.btnViewCat.Text = "Tra Cứu Loại Sản Phẩm";
            this.btnViewCat.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(25, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 16);
            this.label1.TabIndex = 74;
            this.label1.Text = "Tên Loại Sản Phẩm:";
            // 
            // lblCateDes
            // 
            this.lblCateDes.AutoSize = true;
            this.lblCateDes.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCateDes.Location = new System.Drawing.Point(25, 109);
            this.lblCateDes.Name = "lblCateDes";
            this.lblCateDes.Size = new System.Drawing.Size(54, 16);
            this.lblCateDes.TabIndex = 75;
            this.lblCateDes.Text = "Mô Tả:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(25, 138);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 16);
            this.label2.TabIndex = 74;
            this.label2.Text = "Tên Sản Phẩm:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(25, 167);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 16);
            this.label3.TabIndex = 74;
            this.label3.Text = "Quy Cách:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(355, 163);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 16);
            this.label4.TabIndex = 74;
            this.label4.Text = "Đơn Giá:";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox1.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.Location = new System.Drawing.Point(364, 189);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(162, 20);
            this.checkBox1.TabIndex = 76;
            this.checkBox1.Text = "Ngưng Kinh Doanh";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.textBox1.Location = new System.Drawing.Point(169, 73);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(357, 23);
            this.textBox1.TabIndex = 77;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.textBox2.Location = new System.Drawing.Point(169, 102);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(357, 23);
            this.textBox2.TabIndex = 77;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.textBox3.Location = new System.Drawing.Point(169, 131);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(357, 23);
            this.textBox3.TabIndex = 77;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.textBox4.Location = new System.Drawing.Point(421, 160);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(105, 23);
            this.textBox4.TabIndex = 77;
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.textBox5.Location = new System.Drawing.Point(169, 160);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(180, 23);
            this.textBox5.TabIndex = 77;
            // 
            // dgvSupplier
            // 
            this.dgvSupplier.BackgroundColor = System.Drawing.SystemColors.Info;
            this.dgvSupplier.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSupplier.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IdColumn,
            this.NameColumn,
            this.AddressColumn,
            this.DelColumn,
            this.EditColumn});
            this.dgvSupplier.GridColor = System.Drawing.SystemColors.Info;
            this.dgvSupplier.Location = new System.Drawing.Point(555, 27);
            this.dgvSupplier.Name = "dgvSupplier";
            this.dgvSupplier.RowTemplate.Height = 24;
            this.dgvSupplier.Size = new System.Drawing.Size(773, 257);
            this.dgvSupplier.TabIndex = 78;
            // 
            // IdColumn
            // 
            this.IdColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.IdColumn.DataPropertyName = "Id";
            this.IdColumn.HeaderText = "Mã Loại Sản Phẩm";
            this.IdColumn.Name = "IdColumn";
            this.IdColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // NameColumn
            // 
            this.NameColumn.DataPropertyName = "Name";
            this.NameColumn.HeaderText = "Tên Loại Sản Phẩm";
            this.NameColumn.Name = "NameColumn";
            this.NameColumn.Width = 200;
            // 
            // AddressColumn
            // 
            this.AddressColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.AddressColumn.DataPropertyName = "Address";
            this.AddressColumn.HeaderText = "Địa Chỉ";
            this.AddressColumn.Name = "AddressColumn";
            // 
            // DelColumn
            // 
            this.DelColumn.HeaderText = "Xóa";
            this.DelColumn.Name = "DelColumn";
            this.DelColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.DelColumn.Width = 35;
            // 
            // EditColumn
            // 
            this.EditColumn.HeaderText = "Sửa";
            this.EditColumn.Name = "EditColumn";
            this.EditColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.EditColumn.Width = 35;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(25, 196);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(133, 16);
            this.label5.TabIndex = 74;
            this.label5.Text = "Số Lượng Đã Bán:";
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.textBox6.Location = new System.Drawing.Point(169, 189);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(180, 23);
            this.textBox6.TabIndex = 77;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(25, 225);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(126, 16);
            this.label6.TabIndex = 74;
            this.label6.Text = "Tổng Doanh Thu:";
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.textBox7.Location = new System.Drawing.Point(169, 218);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(180, 23);
            this.textBox7.TabIndex = 77;
            // 
            // fCategories
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1328, 351);
            this.Controls.Add(this.dgvSupplier);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.lblCateDes);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnReturnHome);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnRemCat);
            this.Controls.Add(this.btnEdiCat);
            this.Controls.Add(this.btnAddCat);
            this.Controls.Add(this.btnViewCat);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "fCategories";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Loại Sản Phẩm - Chương Trình Quản Lý Tiệm Cafe";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSupplier)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem thaoTácToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tìmSảnPhẩmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem theoMãToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem theoTênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem theoNgàyCậpNhậtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tùyChọnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xóaSảnPhẩmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sửaThôngTinSảnPhẩmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xóaSảnPhẩmToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem đóngChứcNăngNàyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trợGiúpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem giớiThiệuChứcNăngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tựKhắcPhụcLỗiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem báoCáoLỗiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem giớiThiệuVềChươngTrìnhToolStripMenuItem;
        private System.Windows.Forms.Button btnReturnHome;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnRemCat;
        private System.Windows.Forms.Button btnEdiCat;
        private System.Windows.Forms.Button btnAddCat;
        private System.Windows.Forms.Button btnViewCat;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblCateDes;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.DataGridView dgvSupplier;
        private System.Windows.Forms.DataGridViewTextBoxColumn IdColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn NameColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn AddressColumn;
        private System.Windows.Forms.DataGridViewButtonColumn DelColumn;
        private System.Windows.Forms.DataGridViewButtonColumn EditColumn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox7;
    }
}