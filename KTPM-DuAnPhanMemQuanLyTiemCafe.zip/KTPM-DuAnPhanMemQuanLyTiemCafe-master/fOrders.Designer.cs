﻿namespace DuAnPhanMemQuanLyTiemCafe
{
    partial class fOrders
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.thaoTácToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tìmSảnPhẩmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.theoMãToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.theoTênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.theoNgàyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.theoXuấtXứToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tùyChỉnhToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thêmSảnPhẩmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chỉnhSửaThôngTinSảnPhẩmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xóaSảnPhẩmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lặpLạiThaoTácVừaThựcHiệnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.khôiPhụcDữLiệuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xuấtDữLiệuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nhậpDữLiệuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đóngChứcNăngNàyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trợGiúpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.giớiThiệuChứcNăngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gỡLỗiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.báoCáoLỗiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.giớiThiệuVềChươngTrìnhToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.theoNgàyToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.theoTuầnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.theoThángToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.theoNămToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tùyChỉnhToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thaoTácToolStripMenuItem,
            this.trợGiúpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(470, 26);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // thaoTácToolStripMenuItem
            // 
            this.thaoTácToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tìmSảnPhẩmToolStripMenuItem,
            this.thêmSảnPhẩmToolStripMenuItem,
            this.chỉnhSửaThôngTinSảnPhẩmToolStripMenuItem,
            this.xóaSảnPhẩmToolStripMenuItem,
            this.lặpLạiThaoTácVừaThựcHiệnToolStripMenuItem,
            this.khôiPhụcDữLiệuToolStripMenuItem,
            this.đóngChứcNăngNàyToolStripMenuItem});
            this.thaoTácToolStripMenuItem.Name = "thaoTácToolStripMenuItem";
            this.thaoTácToolStripMenuItem.Size = new System.Drawing.Size(84, 22);
            this.thaoTácToolStripMenuItem.Text = "Thao Tác";
            // 
            // tìmSảnPhẩmToolStripMenuItem
            // 
            this.tìmSảnPhẩmToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.theoMãToolStripMenuItem,
            this.theoTênToolStripMenuItem,
            this.theoNgàyToolStripMenuItem,
            this.theoXuấtXứToolStripMenuItem,
            this.tùyChỉnhToolStripMenuItem});
            this.tìmSảnPhẩmToolStripMenuItem.Name = "tìmSảnPhẩmToolStripMenuItem";
            this.tìmSảnPhẩmToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.tìmSảnPhẩmToolStripMenuItem.Text = "Tìm Đơn Hàng";
            // 
            // theoMãToolStripMenuItem
            // 
            this.theoMãToolStripMenuItem.Name = "theoMãToolStripMenuItem";
            this.theoMãToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.theoMãToolStripMenuItem.Text = "Theo Mã";
            // 
            // theoTênToolStripMenuItem
            // 
            this.theoTênToolStripMenuItem.Name = "theoTênToolStripMenuItem";
            this.theoTênToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.theoTênToolStripMenuItem.Text = "Theo Tên";
            // 
            // theoNgàyToolStripMenuItem
            // 
            this.theoNgàyToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.theoNgàyToolStripMenuItem1,
            this.theoTuầnToolStripMenuItem,
            this.theoThángToolStripMenuItem,
            this.theoNămToolStripMenuItem,
            this.tùyChỉnhToolStripMenuItem1});
            this.theoNgàyToolStripMenuItem.Name = "theoNgàyToolStripMenuItem";
            this.theoNgàyToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.theoNgàyToolStripMenuItem.Text = "Theo Thời Gian";
            // 
            // theoXuấtXứToolStripMenuItem
            // 
            this.theoXuấtXứToolStripMenuItem.Name = "theoXuấtXứToolStripMenuItem";
            this.theoXuấtXứToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.theoXuấtXứToolStripMenuItem.Text = "Theo Xuất Xứ";
            // 
            // tùyChỉnhToolStripMenuItem
            // 
            this.tùyChỉnhToolStripMenuItem.Name = "tùyChỉnhToolStripMenuItem";
            this.tùyChỉnhToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.tùyChỉnhToolStripMenuItem.Text = "Tùy Chỉnh";
            // 
            // thêmSảnPhẩmToolStripMenuItem
            // 
            this.thêmSảnPhẩmToolStripMenuItem.Name = "thêmSảnPhẩmToolStripMenuItem";
            this.thêmSảnPhẩmToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.thêmSảnPhẩmToolStripMenuItem.Text = "Thêm Đơn Hàng";
            // 
            // chỉnhSửaThôngTinSảnPhẩmToolStripMenuItem
            // 
            this.chỉnhSửaThôngTinSảnPhẩmToolStripMenuItem.Name = "chỉnhSửaThôngTinSảnPhẩmToolStripMenuItem";
            this.chỉnhSửaThôngTinSảnPhẩmToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.chỉnhSửaThôngTinSảnPhẩmToolStripMenuItem.Text = "Chỉnh Sửa Thông Tin Đơn Hàng";
            // 
            // xóaSảnPhẩmToolStripMenuItem
            // 
            this.xóaSảnPhẩmToolStripMenuItem.Name = "xóaSảnPhẩmToolStripMenuItem";
            this.xóaSảnPhẩmToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.xóaSảnPhẩmToolStripMenuItem.Text = "Xóa Đơn Hàng";
            // 
            // lặpLạiThaoTácVừaThựcHiệnToolStripMenuItem
            // 
            this.lặpLạiThaoTácVừaThựcHiệnToolStripMenuItem.Name = "lặpLạiThaoTácVừaThựcHiệnToolStripMenuItem";
            this.lặpLạiThaoTácVừaThựcHiệnToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.lặpLạiThaoTácVừaThựcHiệnToolStripMenuItem.Text = "Lặp Lại Thao Tác Vừa Thực Hiện";
            // 
            // khôiPhụcDữLiệuToolStripMenuItem
            // 
            this.khôiPhụcDữLiệuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.xuấtDữLiệuToolStripMenuItem,
            this.nhậpDữLiệuToolStripMenuItem});
            this.khôiPhụcDữLiệuToolStripMenuItem.Name = "khôiPhụcDữLiệuToolStripMenuItem";
            this.khôiPhụcDữLiệuToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.khôiPhụcDữLiệuToolStripMenuItem.Text = "Khôi Phục Dữ Liệu";
            // 
            // xuấtDữLiệuToolStripMenuItem
            // 
            this.xuấtDữLiệuToolStripMenuItem.Name = "xuấtDữLiệuToolStripMenuItem";
            this.xuấtDữLiệuToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.xuấtDữLiệuToolStripMenuItem.Text = "Xuất Dữ Liệu";
            // 
            // nhậpDữLiệuToolStripMenuItem
            // 
            this.nhậpDữLiệuToolStripMenuItem.Name = "nhậpDữLiệuToolStripMenuItem";
            this.nhậpDữLiệuToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.nhậpDữLiệuToolStripMenuItem.Text = "Nhập Dữ Liệu";
            // 
            // đóngChứcNăngNàyToolStripMenuItem
            // 
            this.đóngChứcNăngNàyToolStripMenuItem.Name = "đóngChứcNăngNàyToolStripMenuItem";
            this.đóngChứcNăngNàyToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.đóngChứcNăngNàyToolStripMenuItem.Text = "Đóng Chức Năng Này";
            // 
            // trợGiúpToolStripMenuItem
            // 
            this.trợGiúpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.giớiThiệuChứcNăngToolStripMenuItem,
            this.gỡLỗiToolStripMenuItem,
            this.báoCáoLỗiToolStripMenuItem,
            this.giớiThiệuVềChươngTrìnhToolStripMenuItem});
            this.trợGiúpToolStripMenuItem.Name = "trợGiúpToolStripMenuItem";
            this.trợGiúpToolStripMenuItem.Size = new System.Drawing.Size(76, 22);
            this.trợGiúpToolStripMenuItem.Text = "Trợ Giúp";
            // 
            // giớiThiệuChứcNăngToolStripMenuItem
            // 
            this.giớiThiệuChứcNăngToolStripMenuItem.Name = "giớiThiệuChứcNăngToolStripMenuItem";
            this.giớiThiệuChứcNăngToolStripMenuItem.Size = new System.Drawing.Size(254, 22);
            this.giớiThiệuChứcNăngToolStripMenuItem.Text = "Giới Thiệu Chức Năng";
            // 
            // gỡLỗiToolStripMenuItem
            // 
            this.gỡLỗiToolStripMenuItem.Name = "gỡLỗiToolStripMenuItem";
            this.gỡLỗiToolStripMenuItem.Size = new System.Drawing.Size(254, 22);
            this.gỡLỗiToolStripMenuItem.Text = "Gỡ Lỗi";
            // 
            // báoCáoLỗiToolStripMenuItem
            // 
            this.báoCáoLỗiToolStripMenuItem.Name = "báoCáoLỗiToolStripMenuItem";
            this.báoCáoLỗiToolStripMenuItem.Size = new System.Drawing.Size(254, 22);
            this.báoCáoLỗiToolStripMenuItem.Text = "Báo Cáo Lỗi";
            // 
            // giớiThiệuVềChươngTrìnhToolStripMenuItem
            // 
            this.giớiThiệuVềChươngTrìnhToolStripMenuItem.Name = "giớiThiệuVềChươngTrìnhToolStripMenuItem";
            this.giớiThiệuVềChươngTrìnhToolStripMenuItem.Size = new System.Drawing.Size(254, 22);
            this.giớiThiệuVềChươngTrìnhToolStripMenuItem.Text = "Giới Thiệu Về Chương Trình";
            // 
            // theoNgàyToolStripMenuItem1
            // 
            this.theoNgàyToolStripMenuItem1.Name = "theoNgàyToolStripMenuItem1";
            this.theoNgàyToolStripMenuItem1.Size = new System.Drawing.Size(157, 22);
            this.theoNgàyToolStripMenuItem1.Text = "Theo Ngày";
            // 
            // theoTuầnToolStripMenuItem
            // 
            this.theoTuầnToolStripMenuItem.Name = "theoTuầnToolStripMenuItem";
            this.theoTuầnToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.theoTuầnToolStripMenuItem.Text = "Theo Tuần";
            // 
            // theoThángToolStripMenuItem
            // 
            this.theoThángToolStripMenuItem.Name = "theoThángToolStripMenuItem";
            this.theoThángToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.theoThángToolStripMenuItem.Text = "Theo Tháng";
            // 
            // theoNămToolStripMenuItem
            // 
            this.theoNămToolStripMenuItem.Name = "theoNămToolStripMenuItem";
            this.theoNămToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.theoNămToolStripMenuItem.Text = "Theo Năm";
            // 
            // tùyChỉnhToolStripMenuItem1
            // 
            this.tùyChỉnhToolStripMenuItem1.Name = "tùyChỉnhToolStripMenuItem1";
            this.tùyChỉnhToolStripMenuItem1.Size = new System.Drawing.Size(157, 22);
            this.tùyChỉnhToolStripMenuItem1.Text = "Tùy Chỉnh";
            // 
            // fOrders
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(470, 268);
            this.Controls.Add(this.menuStrip1);
            this.Name = "fOrders";
            this.Text = "Đơn Hàng - Chương Trình Quản Lý Tiệm Cafe";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem thaoTácToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tìmSảnPhẩmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem theoMãToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem theoTênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem theoNgàyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem theoNgàyToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem theoTuầnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem theoThángToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem theoNămToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tùyChỉnhToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem theoXuấtXứToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tùyChỉnhToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thêmSảnPhẩmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chỉnhSửaThôngTinSảnPhẩmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xóaSảnPhẩmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lặpLạiThaoTácVừaThựcHiệnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem khôiPhụcDữLiệuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xuấtDữLiệuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nhậpDữLiệuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đóngChứcNăngNàyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trợGiúpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem giớiThiệuChứcNăngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gỡLỗiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem báoCáoLỗiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem giớiThiệuVềChươngTrìnhToolStripMenuItem;
    }
}