﻿namespace DuAnPhanMemQuanLyTiemCafe
{
    partial class fReports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblIncome = new System.Windows.Forms.Label();
            this.txtIncome = new System.Windows.Forms.TextBox();
            this.pnlIncome = new System.Windows.Forms.Panel();
            this.pnlCost = new System.Windows.Forms.Panel();
            this.lblCost = new System.Windows.Forms.Label();
            this.txtCost = new System.Windows.Forms.TextBox();
            this.pnlRevenue = new System.Windows.Forms.Panel();
            this.lblRevenue = new System.Windows.Forms.Label();
            this.txtRevenue = new System.Windows.Forms.TextBox();
            this.btnIncome = new System.Windows.Forms.Button();
            this.btnCost = new System.Windows.Forms.Button();
            this.btnRevenue = new System.Windows.Forms.Button();
            this.pnlIncome.SuspendLayout();
            this.pnlCost.SuspendLayout();
            this.pnlRevenue.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblIncome
            // 
            this.lblIncome.AutoSize = true;
            this.lblIncome.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.lblIncome.Location = new System.Drawing.Point(13, 11);
            this.lblIncome.Name = "lblIncome";
            this.lblIncome.Size = new System.Drawing.Size(101, 19);
            this.lblIncome.TabIndex = 0;
            this.lblIncome.Text = "Doanh Thu:";
            // 
            // txtIncome
            // 
            this.txtIncome.Location = new System.Drawing.Point(126, 3);
            this.txtIncome.Name = "txtIncome";
            this.txtIncome.Size = new System.Drawing.Size(300, 27);
            this.txtIncome.TabIndex = 1;
            // 
            // pnlIncome
            // 
            this.pnlIncome.Controls.Add(this.lblIncome);
            this.pnlIncome.Controls.Add(this.txtIncome);
            this.pnlIncome.Location = new System.Drawing.Point(97, 99);
            this.pnlIncome.Name = "pnlIncome";
            this.pnlIncome.Size = new System.Drawing.Size(426, 33);
            this.pnlIncome.TabIndex = 2;
            // 
            // pnlCost
            // 
            this.pnlCost.Controls.Add(this.lblCost);
            this.pnlCost.Controls.Add(this.txtCost);
            this.pnlCost.Location = new System.Drawing.Point(97, 147);
            this.pnlCost.Name = "pnlCost";
            this.pnlCost.Size = new System.Drawing.Size(426, 34);
            this.pnlCost.TabIndex = 2;
            // 
            // lblCost
            // 
            this.lblCost.AutoSize = true;
            this.lblCost.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.lblCost.Location = new System.Drawing.Point(13, 11);
            this.lblCost.Name = "lblCost";
            this.lblCost.Size = new System.Drawing.Size(71, 19);
            this.lblCost.TabIndex = 0;
            this.lblCost.Text = "Chi Phí:";
            // 
            // txtCost
            // 
            this.txtCost.Location = new System.Drawing.Point(126, 3);
            this.txtCost.Name = "txtCost";
            this.txtCost.Size = new System.Drawing.Size(300, 27);
            this.txtCost.TabIndex = 1;
            // 
            // pnlRevenue
            // 
            this.pnlRevenue.Controls.Add(this.lblRevenue);
            this.pnlRevenue.Controls.Add(this.txtRevenue);
            this.pnlRevenue.Location = new System.Drawing.Point(97, 195);
            this.pnlRevenue.Name = "pnlRevenue";
            this.pnlRevenue.Size = new System.Drawing.Size(426, 32);
            this.pnlRevenue.TabIndex = 2;
            // 
            // lblRevenue
            // 
            this.lblRevenue.AutoSize = true;
            this.lblRevenue.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.lblRevenue.Location = new System.Drawing.Point(13, 11);
            this.lblRevenue.Name = "lblRevenue";
            this.lblRevenue.Size = new System.Drawing.Size(97, 19);
            this.lblRevenue.TabIndex = 0;
            this.lblRevenue.Text = "Lợi Nhuận:";
            // 
            // txtRevenue
            // 
            this.txtRevenue.Location = new System.Drawing.Point(126, 3);
            this.txtRevenue.Name = "txtRevenue";
            this.txtRevenue.Size = new System.Drawing.Size(300, 27);
            this.txtRevenue.TabIndex = 1;
            // 
            // btnIncome
            // 
            this.btnIncome.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnIncome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnIncome.Location = new System.Drawing.Point(211, 249);
            this.btnIncome.Name = "btnIncome";
            this.btnIncome.Size = new System.Drawing.Size(100, 34);
            this.btnIncome.TabIndex = 3;
            this.btnIncome.Text = "Doanh Thu";
            this.btnIncome.UseVisualStyleBackColor = true;
            this.btnIncome.Click += new System.EventHandler(this.btnIncome_Click);
            // 
            // btnCost
            // 
            this.btnCost.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnCost.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCost.Location = new System.Drawing.Point(317, 249);
            this.btnCost.Name = "btnCost";
            this.btnCost.Size = new System.Drawing.Size(100, 34);
            this.btnCost.TabIndex = 3;
            this.btnCost.Text = "Chi Phí";
            this.btnCost.UseVisualStyleBackColor = true;
            // 
            // btnRevenue
            // 
            this.btnRevenue.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnRevenue.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRevenue.Location = new System.Drawing.Point(423, 249);
            this.btnRevenue.Name = "btnRevenue";
            this.btnRevenue.Size = new System.Drawing.Size(100, 34);
            this.btnRevenue.TabIndex = 3;
            this.btnRevenue.Text = "Lợi Nhuận";
            this.btnRevenue.UseVisualStyleBackColor = true;
            // 
            // fReports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(632, 448);
            this.Controls.Add(this.btnRevenue);
            this.Controls.Add(this.btnCost);
            this.Controls.Add(this.btnIncome);
            this.Controls.Add(this.pnlRevenue);
            this.Controls.Add(this.pnlCost);
            this.Controls.Add(this.pnlIncome);
            this.Font = new System.Drawing.Font("Arial", 10F);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "fReports";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Báo Cáo - Chương Trình Quản Lý Tiệm Cafe";
            this.pnlIncome.ResumeLayout(false);
            this.pnlIncome.PerformLayout();
            this.pnlCost.ResumeLayout(false);
            this.pnlCost.PerformLayout();
            this.pnlRevenue.ResumeLayout(false);
            this.pnlRevenue.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblIncome;
        private System.Windows.Forms.TextBox txtIncome;
        private System.Windows.Forms.Panel pnlIncome;
        private System.Windows.Forms.Panel pnlCost;
        private System.Windows.Forms.Label lblCost;
        private System.Windows.Forms.TextBox txtCost;
        private System.Windows.Forms.Panel pnlRevenue;
        private System.Windows.Forms.Label lblRevenue;
        private System.Windows.Forms.TextBox txtRevenue;
        private System.Windows.Forms.Button btnIncome;
        private System.Windows.Forms.Button btnCost;
        private System.Windows.Forms.Button btnRevenue;
    }
}